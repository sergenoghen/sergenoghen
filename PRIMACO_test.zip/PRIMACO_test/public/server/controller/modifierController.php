
<?php
/* Ce controller gère toutes les modifications des données des tables */
    require_once("../modele/assureModele.inc.php");
    
    $tabRes=array();
    
    function epurerDonnees($data){
        $arr = ['(',')','}','{',']','[','=','#'];
        str_ireplace($arr,"",$data);
        htmlspecialchars($data);
        return $data;
    }

    // fonctions php de gestion des differentes requetes//

    $Log['error'] = [];//tableau d'erreurs courantes

    //modifierUsager
    function modifierUsager(){
        global $tabRes;

        $idusers = 3;
        $titre = epurerDonnees( $_POST['titre']);
        $prenom = epurerDonnees( $_POST['prenom']);
        $nom = epurerDonnees( $_POST['nom']);
        $date_naiss = epurerDonnees( $_POST['date_naiss']);
        $email = epurerDonnees( $_POST['email']);
        $anReclam = epurerDonnees( $_POST['reclammation']);

        try{
            $requete="UPDATE users SET titre=?, prenom=?,nom=?, date_naiss=?, email=?, nbreAnneeReclamAnterieure=? WHERE idusers = $idusers";
			$unModele=new assureModele($requete,array($titre,$prenom,$nom,$date_naiss,$email,$anReclam) );
			$stmt=$unModele->executer();
			$tabRes['action']="modifierUsager";
            $tabRes['ok']="Modification réussie!";
            $tabRes['current_user_id'] =  $unModele->lastInsertId();
        }catch(PDOException $e){
            $Log['error'] = [$e->getMessage()];
            //echo $e."<br>";
            echo "<br>".$e->getMessage()."<br>";
            // echo "<br>".$e->errorInfo()."<br>";
			$tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        }finally{
            unset($unModele);
        }

    }//Fin modifierUsager



    //modifierConducteur
    function modifierConducteur(){
        global $tabRes;

        $nom = epurerDonnees( $_POST['nom']);
        $prenom = epurerDonnees( $_POST['prenom']);
        $id_statut_prof = epurerDonnees( $_POST['statut_prof']);
        $police = epurerDonnees( $_POST['exist_police']);
        $id_etat_matri = epurerDonnees( $_POST['etat_matri']);
        $nb_an_conduite = epurerDonnees( $_POST['nb_an_conduite']);
        $user_id= $_POST['user_id'];
        
        try{
            $requete="UPDATE conducteur SET nom=?, prenom=?,exist_ancien_police=?, nb_an_conduite=?, idstatut_prof=?, idetat_matri=?, idusers=? WHERE idusers = $user_id";
			$unModele=new assureModele($requete,[$nom,$prenom,$police,$nb_an_conduite,$id_statut_prof,$id_etat_matri,$user_id] );
			$stmt=$unModele->executer();
			$tabRes['action']="modifierConducteur";
			$tabRes['ok']="Conducteur bien modifié.";
        }catch(PDOExcetion $e){
            $Log['error'] = [$e->getMessage()];
			$tabRes['error']="Oups probleme de modification, ".$e->getMessage();
        }finally{
            unset($unModele);
        }

    }//modifierConducteur


    // 				num_tel	idtype_tel	idconduct


    //modifierCoordonnees
    function modifierCoordonnees(){
        global $tabRes;

        $code_postal = epurerDonnees( $_POST['code_postal']);
        $num_rue = epurerDonnees( $_POST['num_rue']);
        $nom_rue = epurerDonnees( $_POST['nom_rue']);
        $appart_num = epurerDonnees( $_POST['appart_num']);
        $num_tel = epurerDonnees( $_POST['num_tel']);
        $idtype_tel = epurerDonnees( $_POST['idtype_tel']);
        $idconduct= $_POST['idconduct'];
        
        try{
            
            $requete="UPDATE coordonnees SET code_postal=?, num_rue=?,nom_rue=?, appart_num=?, num_tel=?, idtype_tel=?, idconduct=? WHERE idconduct = $idconduct";
			
			$unModele=new assureModele($requete,[$code_postal,$num_rue,$nom_rue,$appart_num,$num_tel,$idtype_tel,$idconduct] );
			$stmt=$unModele->executer();
			$tabRes['action']="modifierCoordonnees";
            $tabRes['ok']="Coordonnées  bien modifiées.";
            $unModele->lastInsertId();
        }catch(PDOExcetion $e){
            $Log['error'] = [$e->getMessage()];
			$tabRes['error']="Oups probleme de modification, ".$e->getMessage();
        }finally{
            unset($unModele);
        }

    }//enregistrerCoordonnees

         //ModifierVehicules
                /* Non fait volontairement */
         //Fin enregistrerVehicules




    //******************************************************
	//Contrôleur
	$action=$_POST['action'];//un input hidden placé dans les forms pour que le controller choisisse la fonctions qui convient
	switch($action){
		case "modifierUsager" :
			modifierUsager();
		break;
		case "modifierConducteur" :
			modifierConducteur();
		break;
		
		case "modifierCoordonnees" :
			modifierCoordonnees();
		break;
    }
    
    
    echo json_encode($tabRes);//Envoyer les données resultat des opérations vers les requetes ajax