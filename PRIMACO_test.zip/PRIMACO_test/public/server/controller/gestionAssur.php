
<?php
/* Ce controller gère tous les enregistrements de données dans la base de données bdassur*/
    require_once("../modele/assureModele.inc.php");
    
    $tabRes = array();
    $user_id = null;
    //$GLOBALS["user_id"];//variables globales
    function epurerDonnees($data){
        $arr = ['(',')','}','{',']','[','=','#'];
        str_ireplace($arr,"",$data);
        htmlspecialchars($data);
        return $data;
    }

    // fonctions php de gestion des differentes requetes//

    $Log['error'] = [];//tableau d'erreurs courantes
    //enregistrerUsager
    function enregistrerUsager(){
        global $tabRes;
        global $user_id;
        $titre = epurerDonnees( $_POST['titre']);
        $prenom = epurerDonnees( $_POST['prenom']);
        $nom = epurerDonnees( $_POST['nom']);
        $date_naiss = epurerDonnees( $_POST['date_naiss']);
        $email = epurerDonnees( $_POST['email']);
        $anReclam = epurerDonnees( $_POST['reclammation']);       

        try{
            $requete = "INSERT INTO users VALUES(0,?,?,?,?,?,?)";
			$unModele = new assureModele($requete,array($titre,$prenom,$nom,$date_naiss,$email,$anReclam) );
			$stmt=$unModele->executer();
			$tabRes['action'] = "enregistrerUsager";
            $tabRes['ok']="Usager bien enregistre.";
            $user_id =  $unModele->lastInsertId();//id de l'usager courant
            $tabRes['user_id'] =   $user_id;
            //$GLOBALS["user_id"] = $user_id;
        }catch(PDOException $e){
            $Log['error'] = $e->getMessage();
           if(stripos($e->getMessage() , "Duplicate entry") > -1){
                $tabRes['error']="Oups probleme d'enregistrement, un usager identique est déjà enregistré!";
           }else
            $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
            
        }finally{
            unset($unModele);
        }

    }//Fin enregistrerUsager

       //$tabRes['user_id'];
        

    //enregistrerConducteur
    function enregistrerConducteur(){
        global $tabRes;
        //$user_id =  $GLOBALS["user_id"];
        $nom = epurerDonnees( $_POST['nom']);
        $prenom = epurerDonnees( $_POST['prenom']);
        $id_statut_prof = epurerDonnees( $_POST['statut_prof']);
        $police = epurerDonnees( $_POST['exist_police']);
        $id_etat_matri = epurerDonnees( $_POST['etat_matri']);
        $nb_an_conduite = epurerDonnees( $_POST['nb_an_conduite']);
        $user_id = $_POST['user_id'];
        
        try{
            $requete="INSERT INTO conducteurs VALUES(0,?,?,?,?,?,?,?)";
			$unModele=new assureModele($requete,[$nom, $prenom, $police, $nb_an_conduite, $id_statut_prof, $id_etat_matri , $user_id] );
			$stmt=$unModele->executer();
			$tabRes['action']="enregistrerConducteur";
            $tabRes['ok']="Conducteur ".$prenom." bien enregistré.";
            
            $tabRes['current_user_id'] =  $user_id;//id
            $tabRes['idconduct'] =  $unModele->lastInsertId();
        }catch(PDOExcetion $e){
            $Log['error'] = [$e->getMessage()];
			$tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        }finally{
            unset($unModele);
        }

    }//enregistrerConducteur



    //enregistrerCoordonnees
    function enregistrerCoordonnees(){
        global $tabRes;

        $code_postal = epurerDonnees( $_POST['code_postal']);
        $num_rue = epurerDonnees( $_POST['num_rue']);
        $nom_rue = epurerDonnees( $_POST['nom_rue']);
        $appart_num = epurerDonnees( $_POST['appart_num']);
        $num_tel = epurerDonnees( $_POST['num_tel']);
        $idtype_tel = epurerDonnees( $_POST['idtype_tel']);
        $idconduct = $_POST['idconduct'];
        
        try{
            $requete="INSERT INTO coordonnees VALUES(0,?,?,?,?,?,?,?)";
			$unModele=new assureModele($requete,[$code_postal,$num_rue,$nom_rue,$appart_num,$num_tel,$idtype_tel,$idconduct] );
			$stmt=$unModele->executer();
			$tabRes['action']="enregistrerCoordonnees";
            $tabRes['ok']="Coordonnées bien enregistrées.";
             $unModele->lastInsertId() ;
        }catch(PDOExcetion $e){
            $Log['error'] = [$e->getMessage()];
			$tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        }finally{
            unset($unModele);
        }

    }//enregistrerCoordonnees

         //enregistrerVehicules
    function enregistrerVehicules(){
         global $tabRes;

        $annee = epurerDonnees( $_POST['annee']);
        $date_acquisition = epurerDonnees( $_POST['date_acquisition']);
        $km_par_an = epurerDonnees( $_POST['km_par_an']);
        $utilisation_commerciale = epurerDonnees( $_POST['utilisation_commerciale']);
        $date_entree_vigueur = epurerDonnees( $_POST['date_entree_vigueur']);
        $idmarques = epurerDonnees( $_POST['idmarques']);
		$idmodeles = epurerDonnees( $_POST['idmodeles']);
        $idtype_pos = epurerDonnees( $_POST['idtype_pos']);
        $idconduct = epurerDonnees( $_POST['idconduct']);
                
        try{
            $requete="INSERT INTO vehicules VALUES(0,?,?,?,?,?,?,?,?,?)";
			$unModele=new assureModele($requete,[$annee,$date_acquisition,$km_par_an,$utilisation_commerciale,$date_entree_vigueur,$idmarques,$idmodeles,$idconduct,$idtype_pos] );
			$stmt=$unModele->executer();
			$tabRes['action']="enregistrerVehicules";
			$tabRes['ok']="Véhicule numéro " . $unModele->lastInsertId() . " bien enregistré.";
        }catch(PDOExcetion $e){
            $Log['error'] = [$e->getMessage()];
			$tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        }finally{
            unset($unModele);
        }
    } //Fin enregistrerVehicules


         //signUp
    function signUp(){
         global $tabRes;
       
        $pass = epurerDonnees( $_POST['password2']);
        $user_name = epurerDonnees( $_POST['email2']);
        $email = null;
        $idusers=null;
        //$idusers = epurerDonnees( $_POST['idusers']);

        try{
            $req = "SELECT * FROM users WHERE email=?";
            $unModele = new assureModele($req,[$user_name]);
            $sth = $unModele->executer();
            if( ($row = $sth->fetch( PDO::FETCH_OBJ) ) ){
           
                if( $row->email && $user_name == $row->email){
                    $idusers = $row->idusers;
                    //exécuter l'insertion dans la table login
                    try{
                        $requete="INSERT INTO connexion VALUES(?,?,?)";
                        $unModele=new assureModele($requete,[$pass,$user_name,$idusers] );
                     
                        $stmt = $unModele->executer();
                        $unModele->lastInsertId();//déconnxion
                        $tabRes['action']="signUp";
                        $tabRes["ok"] = "Compte créé avec succes, merci pour votre confiance.";
                        
                    }catch(PDOExcetion $e){
                        $Log['error'] = [$e->getMessage()];
                        $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
                    }finally{
                        unset($unModele);
                    }
                }else{
                    
                    //$tabRes["error"] = "Veuillez remplir les informations dans la section parlons de vous avant de proceder à la création de compte.";
                    
                }

            }else{
                
                $tabRes["error"] = "Veuillez remplir les informations dans la section parlons de vous avant de proceder à la création de compte.";
                   
            }

			//$tabRes['ok']="Usager numéro " . $unModele->lastInsertId() . " bien enregistré.";
        }catch(PDOException $e){

            $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        }
            
        
    } //Fin signUp


    //liste des membres enregistrés
    function listeMembre(){
        global $tabRes;
        $res="<table class='container'>";
        $res.="<tr class='row entete'><th class='col'>  Titre </th><th class='col'>  prenom  </th></tr>";
        
        $req = "SELECT * FROM users ";
        $unModele = new assureModele($req);
        $sth = $unModele->executer();
        $count=0;
        while( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
           
            $tabRes['listeMembre'][$count++] = $row;
        }
        $res.="</table>";
        
        $unModele->lastInsertId();//déconnexion
        unset($sth);
       
    }


    //******************************************************
	//Contrôleur
	$action = $_POST['action'];//un input hidden placé dans les forms pour que le controller choisisse la fonction qui convient
	switch($action){
		case "enregistrerUsager" :
			enregistrerUsager();
		break;
		case "enregistrerConducteur" :
			enregistrerConducteur($user_id);
		break;
		
		case "enregistrerCoordonnees" :
			enregistrerCoordonnees();
		break;
		case "enregistrerVehicules" :
			enregistrerVehicules();
		break;
		case "signUp" :
			signUp();
		break;
		case "listeMembre" :
			listeMembre();
		break;
		
    }
    
    
    echo json_encode($tabRes);