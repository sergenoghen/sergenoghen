<?php
/* Ce fichier construit la connexion à la base de données  */
class Connexion{
	private $serveur;
	private $usager;
	private $motPasse;
	private $baseDonnees;
	private $connexion;
	
	function __construct($serveur, $usager, $motPasse, $baseDonnees){
		$this->serveur = $serveur;
		$this->usager = $usager;
		$this->motPasse = $motPasse;
		$this->baseDonnees = $baseDonnees;
	}
	
	function getConnexion(){
		return $this->connexion;
	}
	
	function connecter(){
		//$last_id = null;
	   try {
		  $dns = "mysql:host=$this->serveur;dbname=$this->baseDonnees";
		  $options = array(
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		  );
		  $this->connexion = new PDO( $dns, $this->usager, $this->motPasse, $options );
		  $connect_id = $this->connexion->query('SELECT CONNECTION_ID()')->fetch(PDO::FETCH_ASSOC)['CONNECTION_ID()'];
		  
		} catch ( Exception $e ) {
			echo $e->getMessage();
			echo "<br>Probleme de connexion au serveur de bd";
			exit();
		}
		//return $last_id;
	}
	
	
}




















    // define("SERVEUR","localhost");
    // define("USAGER","root"); 
    // define("PASSE","");
    // define("BD","bdassur");
  
    // $conn = null;
    // try {
    // $conn = new PDO("mysql:host=".SERVER.";dbname=".BD, USAGER, PASSE);
    // // set the PDO error mode to exception
    // $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //     //echo "Connected successfully";
    // } catch(PDOException $e) {
    //     echo "Connection failed: " . $e->getMessage();
    //     exit();
    // }