
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier soumission - Assurance automobile en ligne </title>
    <script src="../../src/js/jquery-3.5.1.min.js"></script>
    <script src="../../src/bootstrap-4.5.0/assets/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../../src/bootstrap-4.5.0/assets/dist/css/bootstrap.min.css">
    <script src="../requetes/requeteModifier.js"></script>
    <link rel="stylesheet" href="../../src/css/style.css">
    <?php

     
      // // Définit les cookies
      // setcookie("cookie[three]", "cookiethree");
      // setcookie("cookie[two]", "cookietwo");
      // setcookie("cookie[one]", "cookieone");
      // setcookie("idconduct", 1);
      // setcookie("user_id", "1");//on récupère l'id de l'usager courant par un select
      // setcookie("code_postal", "H3G 5B7" );//$_POST['code']

    
    ?>
    
</head>
<body >
    
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="../../">Brand</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="../../">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#auto">Assurance auto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#habitation">Assurance habitation</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#apropos">A propos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact</a>
            </li>
          </ul>
          <span class="navbar-text">
           
          </span>
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <!-- <a class="nav-link" href="#espace">Espace client</a> -->
              <!--  dopdown button for options of espace client -->
              <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Espace client
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" data-toggle="modal" data-target="#loginModal" href="#loginModal">Se connecter</a>
                  <div class="dropdown-divider"></div><!--diviseur de dropdown-items -->
                  <a class="dropdown-item" data-toggle="modal" data-target="#connectModal" href="#connectModal">Créer un compte</a>
                </div>
              </div>
            </li>
          </ul>
        </div>
    </nav>
    <div class="content" id="content">
          <h3 class="container">  Assurance automobile en ligne</h3> 

        
          
          <div class="separateur"></div>
          

          <h5 class="conatainer titre" id=""> Services offerts</h5> 
          
           <!-- assurance automobile -->
          <div class="container  btn-success" id="automobile" >
            <h5 class="titre">Assurance automobile</h5>
           
          </div><!-- / automobile <br>-->

          
          <!-- affiche modifier -->
          <span id="modif">Modification des données d'une soumission</span>
          <div class="content" id="modifier">
 <?php
      require_once("../modele/assureModele.inc.php");
          
      $tabRes=array();
      $tabIdConduct=array();

      //modifierUsager
      function modifierUsager(){
          $modifierUsager = "";

          global $tabRes;
            
          $idusers = 3;
            $req = "SELECT * FROM users WHERE idusers =  $idusers ";
            $unModele = new assureModele($req);
            $sth = $unModele->executer();
            $count=0;
            if( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
              

                $modifierUsager.= "<div class=\"modifierUsager page container\" id=\"page1\">\n";
                $modifierUsager.= "<h5 class=\"titre\">Modification de l'usager <br></h5>\n";
                $modifierUsager.= "<form id=\"modifierUsager\" method=\"post\" onsubmit=\"return false\"> ";
                $modifierUsager.= "  <div class=\"form-group\">\n";
                $modifierUsager.= "    <label for=\"titre\">Titre</label>\n";
                $modifierUsager.= "    <select type=\"text\" class=\"form-control\" id=\"titre\" name=\"titre\" >\n";
                $modifierUsager.= "      <option value=\"Monsieur\">Monsieur</option>\n";
                $modifierUsager.= "      <option value=\"Madame\">Madame</option>\n";
                $modifierUsager.= "      <option value=\"Mademoiselle\">Mademoiselle</option>\n";
                $modifierUsager.= "    </select>\n";
                $modifierUsager.= "    <input type=\"hidden\" class=\"form-control\" name=\"action\" value=\"modifierUsager\" hidden>\n";
                $modifierUsager.= "  </div>\n";
                $modifierUsager.= "  <div class=\"form-group\">\n";
                $modifierUsager.= "    <label for=\"prenom\">Prénom</label>\n";
                $modifierUsager.= "    <input type=\"text\" class=\"form-control\" name=\"prenom\"  id=\"prenom\" value='". $row->prenom ."' required>\n";
                $modifierUsager.= "    <label for=\"nom\">Nom</label>\n";
                $modifierUsager.= "    <input type=\"text\" class=\"form-control\" name=\"nom\"  id=\"nom\" value='". $row->nom ."' required>\n";
                $modifierUsager.= "    <label for=\"email\">Courriel</label>\n";
                $modifierUsager.= "    <input type=\"email\" class=\"form-control\" name=\"email\"  id=\"email\" value=\"". $row->email ."\" required>\n";
                $modifierUsager.= "    <label for=\"reclammation\">À combien d'années remonte votre  dernière reclammation?</label>\n";
                $modifierUsager.= "    <input type=\"number\" class=\"form-control\" name=\"reclammation\"  id=\"reclammation\" value='". $row->nbreAnneeReclamAnterieure ."' min=\"0\" max='50' required>\n";
                $modifierUsager.= "    <label for=\"date_naiss\">Date de naissance</label>\n";
                $modifierUsager.= "    <input type=\"date\" class=\"form-control\" name=\"date_naiss\"  id=\"date_naiss\" value=\"". $row->date_naiss ."\" required>\n";
                $modifierUsager.= "  </div>\n";
                $modifierUsager.= "  <button type=\"reset\" class=\"btn btn-danger\">Effacer</button> \n";
                $modifierUsager.= "  <button type=\"submit\" name=\"submit\" class=\"btn btn-primary\" data-dismiss=\"modal\" onclick=\"requeteModifier('modifierUsager')\" >Envoyer</button>\n";
                $modifierUsager.= "</form>\n";
                $modifierUsager.= "</div> ";

            }
              
            
            $unModele->lastInsertId();//déconnexion
                        unset($sth);
            //echo $res;
          echo $modifierUsager;

      }

      modifierUsager();




      					
          //modifierConducteur 
  function modifierConducteur(){ 
  
    global $tabRes;
    global $tabIdConduct;
      
    $idusers = $_COOKIE['user_id'];//=$_SESSION['user_id'];
      $req = "SELECT * FROM conducteurs WHERE idusers =  $idusers ";
      $unModele = new assureModele($req);
      $sth = $unModele->executer();
      $count=2;
      $res="";
      while( $row = $sth->fetch( PDO::FETCH_OBJ)  ){  

          array_push($tabIdConduct, $row->idconduct);

          $modifierConducteur="<br>" ; 

          $modifierConducteur.=" <div class=\"modifierConducteur  page  container\" id=\"page2\">\n";
          $modifierConducteur.="            <h5  class=\"titre\">Conducteur  </h5>\n";
          $modifierConducteur.="            <form  method=\"post\" id=\"modifierConducteur\" onsubmit=\"return false\"> \n";
          $modifierConducteur.="              <div class=\"form-group\">\n";
          $modifierConducteur.="                <label for=\"titre2\">État matrimonial</label>\n";
          $modifierConducteur.="                <select type=\"text\" class=\"form-control\" id=\"etat_matri\" name=\"etat_matri\" >\n";
          $modifierConducteur.="                  <option value=\"1\">Marié</option>\n";
          $modifierConducteur.="                  <option value=\"2\">Veuf</option>\n";
          $modifierConducteur.="                  <option value=\"3\">Divorcé</option>\n";
          $modifierConducteur.="                  <option value=\"4\">Célibataire</option>\n";
          $modifierConducteur.="                  <option value=\"5\">Conjoint de fait</option>\n";
          $modifierConducteur.="                </select>\n";
          $modifierConducteur.="                <label for=\"nom2\">Nom</label>\n";
          $modifierConducteur.="                <input type=\"text\"  class=\"form-control\" name=nom id=nom2 value=".$row->nom." required>\n";
          $modifierConducteur.="                <label for=\"prenom2\">Prénom</label>\n";
          $modifierConducteur.="                <input type=\"text\"  class=\"form-control\" name=prenom id=prenom2 value=".$row->prenom." required>\n";
          $modifierConducteur.="              </div>\n";
          $modifierConducteur.="              <div class=\"form-group\">\n";
          $modifierConducteur.="                <label for=\"statut_prof\">statut professionnel</label>\n";
          $modifierConducteur.="                <select type=\"text\" class=\"form-control\" id=\"statut_prof\" name=\"statut_prof\" >\n";
          $modifierConducteur.="                  <option value=\"1\">Employé</option>\n";
          $modifierConducteur.="                  <option value=\"2\">Retraité</option>\n";
          $modifierConducteur.="                  <option value=\"3\">Étudiant</option>\n";
          $modifierConducteur.="                  <option value=\"4\">Travailleur autonome</option>\n";
          $modifierConducteur.="                  <option value=\"5\">Propriétaire d'entreprise</option>\n";
          $modifierConducteur.="                  <option value=\"6\">Sans emploi</option>\n";
          $modifierConducteur.="                </select>\n";
          $modifierConducteur.="                <label for=\"exist_police\">Existe-t-il une ancienne police?</label>\n";
          $modifierConducteur.="                <fieldset>\n";
          $modifierConducteur.="                <legend></legend>\n";
          $modifierConducteur.="                  <div class=\"input-group mb-3\">\n";
          $modifierConducteur.="                    <div class=\"input-group-prepend\">\n";
          $modifierConducteur.="                      <span class=\"input-group-text\">Oui</span>\n";
          $modifierConducteur.="                    </div>\n";
          $modifierConducteur.="                    <input type=\"checkbox\" class=\"form-control check\" value=1 name=\"exist_police\"  id=\"exist_police1\"   >\n";
          $modifierConducteur.="                    <div class=\"input-group-prepend\">\n";
          $modifierConducteur.="                      <span class=\"input-group-text\">Non</span>\n";
          $modifierConducteur.="                    </div>\n";
          $modifierConducteur.="                    <input type=\"checkbox\" class=\"form-control check\"  value=0 name=\"exist_police\"  id=\"exist_police2\" />\n";
          $modifierConducteur.="                  </div>\n";
          $modifierConducteur.="                </fieldset>\n";
          $modifierConducteur.="                <label for=\"nb_an_conduite\">Nombre année de conduite</label>\n";
          $modifierConducteur.="                <input type=\"number\" class=\"form-control\" name=\"nb_an_conduite\"  id=\"nb_an_conduite\" min=0 max=50 length=\"2\" value='$row->nb_an_conduite' required/>\n";
          $modifierConducteur.="                <input type=\"text\" value= $idusers name=\"user_id\" id=\"user_id2\" hidden>\n";
          $modifierConducteur.="              </div>\n";
          $modifierConducteur.="                <input type=\"hidden\" class=\"form-control\" name=\"action\" value=modifierConducteur hidden >\n";
          $modifierConducteur.="              <button type=\"submit\" name=submit class=\"btn btn-primary\" data-dismiss=\"modal\" onclick=\"requeteModifier('modifierConducteur')\" >Envoyer</button>\n";
          $modifierConducteur.="            </form>\n";
          $modifierConducteur.="          </div>";
                          
        $res.= $modifierConducteur;
    }
     
    echo $res;
            
    $unModele->lastInsertId();//déconnexion
                unset($sth);

    return $tabIdConduct;
}

$tabIdConduct = modifierConducteur();
      // Fin modifierConducteur


      //***************************** */

      //modifierCoordonnees 
    function modifierCoordonnees(){//afficher les coordonnées des conducteurs de l'utilisateur courant
      
      global $tabRes;
      global $tabIdConduct;
        
        $idusers = 4;//=$_SESSION['user_id'];
        $code_postal="";
        $idconduct1=1;
        $idconduct2=1;
        $strId ="";
        //tous les conducteurs de l'usager courant
        $req = "SELECT * FROM coordonnees WHERE idconduct IN ( ";
        for($i=0; $i < sizeof( $tabIdConduct); $i++){ 
          $req.= $tabIdConduct[$i];
          if($i+1 < sizeof( $tabIdConduct) ){$req.=",";}
        }
        $req.=")";

        $unModele = new assureModele($req);
        $sth = $unModele->executer();
        $count=1;
        $res="";
        while( $row = $sth->fetch( PDO::FETCH_OBJ)  ){  
          $modifierCoordonnees="";
		      $modifierCoordonnees.= "<div class=\"modifierCoordonnees  page  container\" id=\"page3\">\n";
          $modifierCoordonnees.= "            <h5  class=\"titre\"> Coordonnées du conducteur ". $count ."</h5><br>\n";
          $modifierCoordonnees.= "            <form  id=\"modifierCoordonnees\" method=\"post\" onsubmit=\"return false\">";
          $modifierCoordonnees.= "              <div class=\"form-group\"> \n";
          $modifierCoordonnees.= "                <label for=\"code\">Code postal</label>\n";
          $modifierCoordonnees.= "                <input type=\"text\" class=\"form-control\" name=\"code_postal\"  id=\"code_postal\" maxlength=\"7\" value='$row->code_postal' >\n";
          $modifierCoordonnees.= "                <label for=\"num_rue\">Numéro de rue</label>\n";
          $modifierCoordonnees.= "                <input type=\"number\" class=\"form-control\" name=\"num_rue\"  id=\"num_rue\" min=1 value='$row->num_rue' required>\n";
          $modifierCoordonnees.= "                <label for=\"nom_rue\">Nom de rue</label>\n";
          $modifierCoordonnees.= "                <input type=\"text\" class=\"form-control\" name=\"nom_rue\"  id=\"nom_rue\" value='$row->nom_rue'  required>\n";
          $modifierCoordonnees.= "                <label for=\"appart_num\">Numéro d'appartement</label>\n";
          $modifierCoordonnees.= "                <input type=\"number\" class=\"form-control\" name=\"appart_num\"  id=\"appart_num\" min=1 value='$row->appart_num'  required>\n";
          $modifierCoordonnees.= "                <label for=\"num_tel\">Numéro de téléphone</label>\n";
          $modifierCoordonnees.= "                <input type=\"number\" class=\"form-control\" name=\"num_tel\"  id=\"num_tel\" maxlength=\"12\" min='1' value='$row->num_tel'  required>\n";
          $modifierCoordonnees.= "\n";
          $modifierCoordonnees.= "                <label for=\"titre\">Type de télélphone</label>\n";
          $modifierCoordonnees.= "                <select class=\"form-control\" id=\"idtype_tel\" name=\"idtype_tel\" >\n";
          $modifierCoordonnees.= "                  <option value=\"1\">Fixe</option>\n";
          $modifierCoordonnees.= "                  <option value=\"2\">Mobile</option>\n";
          $modifierCoordonnees.= "                  <option value=\"3\">Travail</option>\n";
          $modifierCoordonnees.= "                </select>\n";
          $modifierCoordonnees.= "                <input type=\"hidden\" class=\"form-control\" name=\"action\" value=\"modifierCoordonnees\" hidden>\n";
          $modifierCoordonnees.= "              </div>\n";
          $modifierCoordonnees.= "              <div class=\"form-group\">\n";
          $modifierCoordonnees.= "              <input type=\" hidden\" value=".$row->idconduct."  name=\"idconduct\" id=\"idconduct1\" hidden>\n";
          $modifierCoordonnees.= "              </div>\n";
          $modifierCoordonnees.= "              <button type=\"reset\" class=\"btn btn-danger\">Effacer</button> \n";
          $modifierCoordonnees.= "              <button type=\"submit\" class=\"btn btn-primary\" data-dismiss=\"modal\" onclick=\"requeteModifier('modifierCoordonnees')\" >Envoyer</button>\n";
          $modifierCoordonnees.= "            </form>\n";
          $modifierCoordonnees.= "          </div>";

        $res.= $modifierCoordonnees;
        }
    
    echo $res;
        
$unModele->lastInsertId();//déconnexion
            unset($sth);

    }

    modifierCoordonnees();
	//modifierCoordonnees 






  ?>
            
          </div><br>
          <!-- / affiche modifier -->


          <!-- Modal login-->
          <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="loginModalLabel">Connectez-vous à votre compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form method="post" id="login" >
                    <div class="form-group">
                      <label for="email1">Email address</label>
                      <input type="email" class="form-control" id="email1" name="email1" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password1">Password</label>
                      <input type="password" class="form-control" id="password1"  name="password1" placeholder="Password" required>
                    </div>
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="check1"  name="check1" value=1>
                      <label class="form-check-label" for="Check1">Se souvenir de moi</label>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary" onclick="requeteLogin('login')">Envoyer</button>
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal login -->
         

          
          <!-- Modal signUp-->
          <div class="modal fade" id="connectModal" tabindex="-1" role="dialog" aria-labelledby="connectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="connectModalLabel">Créer un compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form  method="post"  id="signUp" onsubmit="return false"> <!--action="./server/controller/gestionAssur.php" -->
                  <span id="msgsu"></span>
                    <div class="form-group">
                      <label for="email2">Email address</label>
                      <input type="email" class="form-control" id="email2" name="email2" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password2">Password</label>
                      <input type="password" class="form-control" id="password2"  name="password2" maxlength="12" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                      <label for="password2b">Repeat password</label>
                      <input type="password" class="form-control" id="password2b"  name="password2b" maxlength="12" placeholder="Confirm Password" required>
                      <input type="hidden"  name="action" value="signUp" hidden>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary" data-dismiss="modal" onclick="requeteEnreg('signUp')" >Envoyer</button>
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal sign-up -->



          <!-- Fin de soumission -->
          <div class="enregistrerVehicules  page  container" id="page5">
              <button type="submit" class="btn-success" onclick="$('#content').html('<div class=container>Merci pour avoir faite votre soumission. Nous vous contactera sous peu pour les détails de la prime.</div>')" >Envoyer la soumission</button>
              <!-- <button type="button" class="btn-primary"  >Modifier</button> -->
              <button type="button" class="btn-danger" >Supprimer</button>
         </div>


    </div> <!-- / content-->

      <footer class="footer container" id="">
        
        <div>Bas de page</div>
        <!-- Pagination -->
        <nav aria-label="..." id="nav-pagination">
          <div class="" id="msg" ></div>
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
            </li>
            <li class="page-item active"><a class="page-link" href="#page1">1</a></li>
            <li class="page-item " aria-current="page">
              <a class="page-link" href="#page2">2 <span class="sr-only">(current)</span></a>
            </li>
            <li class="page-item"><a class="page-link" href="#page3">3</a></li>
            <li class="page-item"><a class="page-link" href="#page4">4</a></li>
            <li class="page-item"><a class="page-link" href="#page5">5</a></li>
            <li class="page-item">
              <a class="page-link" href="#">Next</a>
            </li>
          </ul>
        </nav>
        <div class="separateur"></div>
      </footer>
    
</body>

<script src="../../src/js/script.js"></script>
<!-- <script src="../../src/js/modifier.js"></script> -->
</html>