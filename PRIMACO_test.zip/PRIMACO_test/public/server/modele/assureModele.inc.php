    <?php
    /** Ce fichier construit le modèle de la base de données, et gère la connexion et la déconnexion  */
    require_once("../connexion/connection.inc.php");
    class assureModele{
        private $requete;
        private $params;//tableau des données à envoyer au server
        private $connexion;
        private $last_id;
        
    function __construct($requete=null,$params=null){
            $this->requete = $requete;
            $this->params = $params;            
    }
        
    function obtenirConnexion(){
        $maConnexion = new Connexion("localhost", "root", "", "dbassur");
        $maConnexion->connecter();
        return $maConnexion->getConnexion();
    }

    function executer(){
            $this->connexion = $this->obtenirConnexion();
            $stmt = $this->connexion->prepare($this->requete);
            $data =[];
           
            $stmt->execute($this->params);
            $this->last_id = $this->connexion->lastInsertId();
            $this->deconnecter(); //fermer la connexion apres exécution de la requete
            return $stmt;		
    }

    function deconnecter(){
            unset($this->connexion);
    }
    
    function lastInsertId(){
            //$last_id = $this->connexion->fetchAll('SELECT LAST_INSERT_ID() as last_id');
            
        return $this->last_id;
    }

 }//fin de la classe modele