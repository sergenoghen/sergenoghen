/** Ce fichier gère toutes les requetes de modification veant du controller */

//modifier donnees 
function requeteModifier(formId){
	var formAssur = new FormData(document.getElementById(formId));
	formAssur.append('action',formId);
	
	$.ajax({
		type : 'POST',
		url : '../controller/modifierController.php',
		data : formAssur,
		dataType : 'json', //text pour le voir en format de string
		async : true,
		cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){
			//alert(reponse);
			var msg="";
			if(reponse.ok ){
				msg =reponse.ok;
			$("#msg").css("color","green");
			}else{
				msg = reponse.error;
				$("#msg").css("color","red");
				alert(msg);
			}
			$("#msg").html(msg);
			
		},
		fail : function (err){
			$("#msg").html(err);
		}
	});
}
