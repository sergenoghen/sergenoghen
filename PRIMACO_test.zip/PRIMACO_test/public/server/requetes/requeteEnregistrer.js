/** Ce fichier gère toutes les requetes d'enregistrement de données venant du controller et retourne des données à afficher vers la vue */


var user_id, idconduct;

//listeMembre 
function requetes(){
	var formAssur = new FormData();
	formAssur.append('action','listeMembre');
	
	$.ajax({
		type : 'POST',
		url : './server/controller/gestionAssur.php',
		data : formAssur,
		dataType : 'json', //text pour le voir en format de string
		//async : false,
		cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){
			//alert(reponse);
			//listeMembres(reponse);
		},
		fail : function (err){
		   
		}
	});
}


//listeMembres
function listeMembres(rep){
	var affiche = document.getElementById('affichage');
	tab = rep.listeMembre;
	//alert(tab);
	res="";
	for(index=0; index < tab.length; index++){
		res+=tab[index].titre + " " + tab[index].prenom + "  " + tab[index].nom + "  " + tab[index].date_naiss + "  " + tab[index].email + "<br>";
	}
	if(affiche)
	affiche.innerHTML = res;
}



//enregistrer donnees 
function requeteEnreg(formId){
	var formAssur = new FormData(document.getElementById(formId));
	formAssur.append('action',formId);
	var user_id=null,idconduct=null;
	$.ajax({
		type : 'POST',
		url : './server/controller/gestionAssur.php',
		data : formAssur,
		dataType : 'json', //text pour le voir en format de string
		async : false,//pour que l'exécution se termine avant toutes les suivantes
		cache : false,
		contentType : false,
		processData : false,
		success : function (reponse){
			
			var msg="";
			if(reponse.ok ){
				msg = reponse.ok;
				user_id = reponse.user_id;
				idconduct = reponse.idconduct;
				if(user_id){
					sessionStorage.setItem("user_id",JSON.stringify(user_id));
					document.getElementById("user_id").value = user_id;
				}

				if(idconduct){
					document.getElementById("idconduct1").value = idconduct;
					document.getElementById("idconduct2").value = idconduct;
					sessionStorage.setItem("idconduct",JSON.stringify(idconduct));
				}
				
				$("#msg").css("color","green");
			}else{
				msg = reponse.error;
				$("#msg").css("color","red");
				alert(msg);
			}
			//setTimeout(function(){
				$("#msg").html(msg);
			//},5000);
			
			
		},
		fail : function (err){
			$("#msg").html(err);
		}
	});
	
	return [user_id,idconduct];
}



//Je n'ai pas définit une requete de connexion volontairement
//Elle devait permettre de gérer la connexion à la base de données pour les users