<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assurance en ligne</title>
    <script src="./src/js/jquery-3.5.1.min.js"></script>
    <script src="./src/bootstrap-4.5.0/assets/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./src/bootstrap-4.5.0/assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./src/css/style.css">
    <?php

     
      // Définit les cookies
      setcookie("cookie[three]", "cookiethree");
      setcookie("cookie[two]", "cookietwo");
      setcookie("cookie[one]", "cookieone");

    
    ?>
    
</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="./">Brand</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="./">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#auto">Assurance auto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#habitation">Assurance habitation</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#apropos">A propos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact</a>
            </li>
          </ul>
          <span class="navbar-text">
           
          </span>
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <!-- <a class="nav-link" href="#espace">Espace client</a> -->
              <!--  dopdown button for options of espace client -->
              <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Espace client
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" data-toggle="modal" data-target="#loginModal" href="#loginModal">Se connecter</a>
                  <div class="dropdown-divider"></div><!--diviseur de dropdown-items -->
                  <a class="dropdown-item" data-toggle="modal" data-target="#connectModal" href="#connectModal">Créer un compte</a>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </nav>
      <div class="content" id="">
          <h3 class="container">  Assurance en ligne</h3> 

          <?php
          
         // echo "With current function : ".$generator->current(),PHP_EOL;

          //  $valCoo = $_POST['code'];
          //   setcookie( "TestCookie",$valCoo , strtotime( '+30 days' ) );      
          //   // Après le rechargemet de la page, nous les affichons
          //   if (isset($_COOKIE['cookie'])) {
          //     foreach ($_COOKIE['cookie'] as $name => $value) {
          //         $name = htmlspecialchars($name);
          //         $value = htmlspecialchars($value);        
          //         echo "$name : $value <br />\n";
          //       }
          //   } 
            
          //   echo $_COOKIE['TestCookie'];

          //echo $_SERVER["REMOTE_ADDR"];

          // function get_ip() {
          //   if($_SERVER) {
          //     if($_SERVER['HTTP_X_FORWARDED_FOR'])
          //     $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
          //     elseif($_SERVER['HTTP_CLIENT_IP'])
          //     $ip = $_SERVER['HTTP_CLIENT_IP'];
          //     else
          //     $ip = $_SERVER['REMOTE_ADDR'];
          //   }
          //   else {
          //     if(getenv('HTTP_X_FORWARDED_FOR'))
          //     $ip = getenv('HTTP_X_FORWARDED_FOR');
          //     elseif(getenv('HTTP_CLIENT_IP'))
          //     $ip = getenv('HTTP_CLIENT_IP');
          //     else
          //     $ip = getenv('REMOTE_ADDR');
          //   }
            
          //   return $ip;
          // }
            
          echo 'Propriétaire du script courant : ' . get_current_user();
          echo '<br>'.getmygid();
          echo '<br>'. php_uname('a');
          echo '<br>';

          $REMOTE_ADDR=getenv('REMOTE_ADDR');
          $ip = $REMOTE_ADDR;
          $host = gethostbyaddr($ip);
          echo '<br>'.$host;
            // //echo get_ip();
            // echo "<br>Voir = ";
            // echo getenv('HTTP_CLIENT_IP');
            // echo "<br>Voir = ";
            // echo getenv('REMOTE_ADDR');
            // echo $_POST['code'];
          
          ?>
          
          <div class="container btn-success" id="code_postal" >
            <!-- <h5>Entrer votre code postal</h5> -->
            <form method="post" action="./" >
              <div class="form-group">
                <label for="code_postal">Entrer votre code postal</label>
                <input type="text" class="form-control" id="code" name="code" placeholder=" votre code postal">
              </div>
              <button type="submit" class="btn btn-primary">Envoyer</button>
            </form>
          </div><!-- / code postal-->
          
          <div class="separateur"></div>

          <h5 class="conatainer titre" id=""> Services offerts</h5> 
          
           <!-- assurance automobile -->
          <div class="container content-item btn-success" id="automobile" >
            <h5 class="titre">Assurance automobile</h5>
           <div class="" id="">
              
                SERVICES EN LIGNE
                Gérez vos assurances sans avoir besoin de nous appeler. 
                Faites une soumission aujourd'hui pour avoir la meilleure prime d’assurance de différents véhicules, remisez un véhicule et plus encore!
              
           </div>
          </div><!-- / automobile <br>-->

          <!-- assurance habitation -->
          <div class="container content-item btn-success" id="habitation" >
            <h5 class="titre">Assurance habitation</h5>
            <div class="" id="">
              
              SERVICES EN LIGNE
              Gérez vos assurances sans avoir besoin de nous appeler. 
              Faites une soumission aujourd'hui pour avoir la meilleure prime d’assurance de votre habitation.
            
            </div>
          </div><!-- / habitation <br>-->

           <!-- assurance automobile -->
          <div class="container content-item btn-success" id="automobile" >
            <h5 class="titre">Assurance automobile</h5>
           <div class="" id="">
              
                SERVICES EN LIGNE
                Gérez vos assurances sans avoir besoin de nous appeler. 
                Faites une soumission aujourd'hui pour avoir la meilleure prime d’assurance de différents véhicules, remisez un véhicule et plus encore!
              
           </div>
          </div><!-- / automobile <br>-->

          <!-- Modal login-->
          <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="loginModalLabel">Connectez-vous à votre compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form method="post" action="./pageclient.php">
                    <div class="form-group">
                      <label for="email1">Email address</label>
                      <input type="email" class="form-control" id="email1" name="email1" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password1">Password</label>
                      <input type="password" class="form-control" id="password1"  name="password1" placeholder="Password" required>
                    </div>
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="check1"  name="check1">
                      <label class="form-check-label" for="Check1">Se souvenir de moi</label>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Envoyer</button>
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal login -->
         

          
          <!-- Modal sign-up-->
          <div class="modal fade" id="connectModal" tabindex="-1" role="dialog" aria-labelledby="connectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="connectModalLabel">Créer un compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form  method="post" action="./pageclient.php">
                    <div class="form-group">
                      <label for="email2">Email address</label>
                      <input type="email" class="form-control" id="email2" name="email2" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password2">Password</label>
                      <input type="password" class="form-control" id="password2"  name="password2" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                      <label for="password2b">Password</label>
                      <input type="password" class="form-control" id="password2b"  name="password2b" placeholder="Confirm Password" required>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Envoyer</button>
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal sign-up -->

          <!-- enregistrerUsager-->
          <div class="enregistrerUsager  content-item" id="page1">
            <div>Parlons de vous</div>
            <form action="./server/controller/gestionAssur.php" method="post">
              <div class="form-group">
                <label for="titre">Titre</label>
                <select type="text" class="form-control" id="titre" name="titre" >
                  <option value="Monsieur">Monsieur</option>
                  <option value="Madame">Madame</option>
                  <option value="Mademoiselle">Mademoiselle</option>
                </select>
                <input type="hidden" class="form-control" name="action" value="enregistrerUsager" >
              </div>
              <div class="form-group">
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" name="prenom"  id="prenom" placeholder="Prenom">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" name="nom"  id="nom" placeholder="Nom">
                <label for="date_naiss">Date de naissance</label>
                <input type="date" class="form-control" name="date_naiss"  id="date_naiss" placeholder="Date de naissance">
              </div>
              <button type="submit" class="btn btn-primary">Envoyer</button>
            </form>
          </div> <!-- / enregistrerUsager-->


          <!-- enregistrerConducteur-->
        
          <div class="enregistrerConducteur  content-item" id="page2">
            <div>Parlons de vous</div>
            <form action="./server/controller/gestionAssur.php" method="post">
              <div class="form-group">
                <label for="titre">etat_matri</label>
                <select type="text" class="form-control" id="etat_matri" name="etat_matri" >
                  <option value="1">Marié</option>
                  <option value="2">Célibataire</option>
                  <option value="3">Veuf</option>
                </select>
                <input type="hidden" class="form-control" name="action" value="enregistrerConducteur" >
              </div>
              <div class="form-group">
                <label for="prenom">statut_prof</label>
                <input type="text" class="form-control" name="statut_prof"  id="statut_prof" placeholder="statut_prof" length=1 size=1>
                <label for="nom">exist_police</label>
                <input type="checkbox" class="form-control" name="exist_police"  id="exist_police" placeholder="exist_police">
                <label for="date_naiss">nb_an_conduite</label>
                <input type="number" class="form-control" name="nb_an_conduite"  id="nb_an_conduite" placeholder="nb_an_conduite">
                <input type="number" value="1" name="user_id" id="user_id" hidden>
              </div>
              <button type="submit" class="btn btn-primary">Envoyer</button>
            </form>
          </div> <!-- / enregistrerConducteur-->

      </div> <!-- / content-->

      <footer class="footer" id="">
        
        <div>Bas de page</div>
        <!-- Pagination -->
        <nav aria-label="..." id="nav-pagination">
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
            </li>
            <li class="page-item"><a class="page-link" href="#page1">1</a></li>
            <li class="page-item active" aria-current="page">
              <a class="page-link" href="#page2">2 <span class="sr-only">(current)</span></a>
            </li>
            <li class="page-item"><a class="page-link" href="#page3">3</a></li>
            <li class="page-item">
              <a class="page-link" href="#">Next</a>
            </li>
          </ul>
        </nav>
        <div class="separateur"></div>
      </footer>
    
</body>
</html>