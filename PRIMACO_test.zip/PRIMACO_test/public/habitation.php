<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="./src/js/jquery-3.5.1.min.js"></script>
    <script src="./src/bootstrap-4.5.0/assets/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./src/bootstrap-4.5.0/assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./src/css/style.css">
    <title>Assurance habitation</title>
</head>
<body>
    <h5 class="titre container">Assurance habitation</h5>
    <div>Coming soon</div>
</body>
</html>