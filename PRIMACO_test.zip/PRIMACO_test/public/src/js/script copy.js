

function valide(){
    
    if($("#password2").val().trim() !=  $("#password2b").val().trim() || $("#password2").val().trim().length < 10){
        alert("Les deux mots de passes sont différents. ou invalident");
       $("#msgsu").html("Les deux mots de passes sont différents.");
       $("#msgsu").style.color="red";
       return false;
    }else{
        
       return true;
    }
    return false;
}

$(document).ready(function(){
    $('.check').click(function() {
        $('.check').not(this).prop('checked', false);
    });
});

var tab=[];
function chargerMemoire(formId){
	//sessionStorage.setItem(id,"'"+tab+"'");//panier vide
	var formContent = new FormData(document.getElementById(formId));
	//formContent.append("action",formId);
	//console.log(formContent.keys());
	//console.log(formContent.entries().next());
		//tab=JSON.parse(sessionStorage.getItem("panier"));
		//a = {titre:formContent.get("titre"),prenom:formContent.get('prenom'),nom: formContent.get('nom'),email:formContent.get('email'),reclammation:formContent.get('reclammation'),date_naiss:formContent.get('date_naiss')};
		a= [];i=0;
		 for(e of formContent.values()){
			 console.log(e);
			 a.push(e);
		 }
		tab.push(a);
		sessionStorage.setItem(formId,JSON.stringify(tab));

		//afficher
			var lePanier="<h3>Contenu de votre panier</h3></br>";
			panier=JSON.parse(sessionStorage.getItem(formId));
			for( var elem of panier){
					
			    lePanier+="</br>Élément = "+elem;
				
			    console.log((elem));
			} 
			console.log(panier);
			document.querySelector("#test").innerHTML = lePanier;
		
	
}
	

	// function afficherMemoire(formId) {
	// 	var lePanier="<h3>Contenu de votre panier</h3></br>";
	// 	panier=JSON.parse(sessionStorage.getItem(formId));
	// 	for( var elem of panier){
	// 		lePanier+="</br>Élément = "+elem;
	// 	}
	// 	document.querySelector("#test").innerHTML=lePanier;
	// }
	
	//fin du test

	// sessionStorage.setItem("panier",'[]');//panier vide
	// var panier=null;
	// function ajoutPanier() {
	// 	var idf = document.querySelector("#idf").value;
	// 	panier=JSON.parse(sessionStorage.getItem("panier"));
	// 	panier.push(idf);
	// 	sessionStorage.setItem("panier",JSON.stringify(panier));
	// }

	// function afficherPanier() {
	// 	var lePanier="<h3>Contenu de votre panier</h3></br>";
	// 	panier=JSON.parse(sessionStorage.getItem("panier"));
	// 	for( var elem of panier){
	// 		lePanier+="</br>Élément = "+elem;
	// 	}
	// 	document.querySelector("#votrePanier").innerHTML=lePanier;
	// }