

function valide(){
    
    if($("#password2").val().trim() !=  $("#password2b").val().trim() || $("#password2").val().trim().length < 10){
        alert("Les deux mots de passes sont différents. ou invalident");
       $("#msgsu").html("Les deux mots de passes sont différents.");
       $("#msgsu").style.color="red";
       return false;
    }else{
        
       return true;
    }
    return false;
}

$(document).ready(function(){
    $('.check').click(function() {
        $('.check').not(this).prop('checked', false);
    });
});


function chargerMemoire(formId){
	var tab=[];
		var x = $("#"+formId).serializeArray();
		a=[];
		$.each(x, function(index, field){
			a.push(field.value);
		});

		tab.push(a);
		sessionStorage.setItem(formId,JSON.stringify(tab));
		
		$(" .badge").remove();
}

//remplir les inputs avec les données de sessionStorage
function chargerInputs1(formId){//charger enregistrerUsager
		
		tabObjet=JSON.parse(sessionStorage.getItem(formId));

			leFormul = document.enregistrerUsager;
			$(" .badge1").remove();
		if(tabObjet){
			leFormul.titre.value = tabObjet[0][0];
			leFormul.prenom.value = tabObjet[0][1];
			leFormul.nom.value = tabObjet[0][2]; 
			leFormul.email.value  = tabObjet[0][3];
			leFormul.reclammation.value  = tabObjet[0][4];
			leFormul.date_naiss.value  = tabObjet[0][5];
		}else{
			
			msg="<div class='badge badge1 badge-warning'>Données du formulaire non encore sauvegardées! </div>";
			$("#"+formId).append(msg);
			leFormul.submit.focus();
		}
}


//remplir les inputs
function chargerInputs2(formId){//charger enregistrerConducteur
		
	var formObj = $("#"+formId).serializeArray();
	tabObjet=JSON.parse(sessionStorage.getItem(formId));
	
		leFormul = document.enregistrerConducteur;
		$(" .badge2").remove();
	if(tabObjet){
		leFormul.etat_matri.value = tabObjet[0][0];
		leFormul.nom.value = tabObjet[0][1];
		leFormul.prenom.value = tabObjet[0][2]; 
		leFormul.statut_prof.value  = tabObjet[0][3];
		leFormul.exist_police[tabObjet[0][4]].checked = true;
		leFormul.nb_an_conduite.value = tabObjet[0][5];
	}else{
	
		msg="<div class='badge badge2 badge-warning'>Données du formulaire non encore sauvegardées! </div>";
		$("#"+formId).append(msg);
		leFormul.submit.focus();}
}

//remplir les inputs
function chargerInputs3(formId){//charger enregistrerCoordonnees
		
	var formObj = $("#"+formId).serializeArray();
	tabObjet=JSON.parse(sessionStorage.getItem(formId));
	
	$(" .badge3").remove();
	leFormul = document.enregistrerCoordonnees;
	if(tabObjet){

		leFormul.code_postal.value = tabObjet[0][0];
		leFormul.num_rue.value = tabObjet[0][1];
		leFormul.nom_rue.value = tabObjet[0][2]; 
		leFormul.appart_num.value  = tabObjet[0][3];
		leFormul.num_tel.value = tabObjet[0][4]; 
		leFormul.idtype_tel.value = tabObjet[0][5];
	}else{
	
		msg="<div class='badge badge3 badge-warning'>Données du formulaire non encore sauvegardées! </div>";
		$("#"+formId).append(msg);
		leFormul.submit.focus();
	}
}

//remplir les inputs
function chargerInputs4(formId){//charger enregistrerVehicules
		
	tabObjet=JSON.parse(sessionStorage.getItem(formId));
		
	$(" .badge4").remove();
		leFormul = document.enregistrerVehicules;
	if(tabObjet){
		leFormul.annee.value = tabObjet[0][0];
		leFormul.date_acquisition.value = tabObjet[0][1];
		leFormul.km_par_an.value = tabObjet[0][2]; 
		leFormul.utilisation_commerciale[tabObjet[0][3]].checked = true;
		leFormul.date_entree_vigueur.value = tabObjet[0][4]; 
		leFormul.idmarques.value = tabObjet[0][5];
		leFormul.idmodeles.value = tabObjet[0][6];
		leFormul.idtype_pos.value = tabObjet[0][7];

	}else{
		msg="<div class='badge badge4 badge-warning'>Données du formulaire non encore sauvegardées! </div>";
		$("#"+formId).append(msg);
		leFormul.submit.focus();
	}

		//console.log($("form#enregistrerConducteur:input"));

}


	//modifier
	function modifier(){
		$(" .badge").remove();
		chargerInputs1("enregistrerUsager");
		chargerInputs2("enregistrerConducteur");
		chargerInputs3("enregistrerCoordonnees");
		chargerInputs4("enregistrerVehicules");
	}
	

	//supprimer
	function supprimer(){
		//supprimer toutes les données de sessionStorage
		sessionStorage.clear();
		
		$(" .badge").remove();
		location.reload();
	}



	//envoyer la soumission
	function envoyer(){//envoyer tous les formulaires complétés

		if(requeteEnreg("enregistrerUsager")[0] != null ){
			console.log("user_id en memoire = "+ JSON.parse(sessionStorage.getItem("user_id")) );
		} 
		requeteEnreg("enregistrerConducteur");
		
		requeteEnreg("enregistrerCoordonnees");
		requeteEnreg("enregistrerVehicules");
		
		$('#content').html('<div class=container>Merci pour avoir faite votre soumission. Nous vous contactera sous peu pour les détails de la prime.</div>');
		
	}


	//nouveau formulaire
	function nouveau(formId){
		$("#"+formId).parent().append($("."+formId).html());
	}
	//fin du test

	// sessionStorage.setItem("panier",'[]');//panier vide
	// var panier=null;
	// function ajoutPanier() {
	// 	var idf = document.querySelector("#idf").value;
	// 	panier=JSON.parse(sessionStorage.getItem("panier"));
	// 	panier.push(idf);
	// 	sessionStorage.setItem("panier",JSON.stringify(panier));
	// }

	// function afficherPanier() {
	// 	var lePanier="<h3>Contenu de votre panier</h3></br>";
	// 	panier=JSON.parse(sessionStorage.getItem("panier"));
	// 	for( var elem of panier){
	// 		lePanier+="</br>Élément = "+elem;
	// 	}
	// 	document.querySelector("#votrePanier").innerHTML=lePanier;
	// }