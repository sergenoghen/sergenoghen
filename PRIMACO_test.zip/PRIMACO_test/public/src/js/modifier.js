var affiche = document.getElementById('Modifier');
affiche.innerHTML = "";

