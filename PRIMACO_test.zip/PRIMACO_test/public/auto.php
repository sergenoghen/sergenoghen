
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assurance automobile en ligne</title>
    <script src="./src/js/jquery-3.5.1.min.js"></script>
    <script src="./src/bootstrap-4.5.0/assets/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./src/bootstrap-4.5.0/assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./src/css/style.css">
    <?php

     
      // Définit les cookies ou variables globales
      // setcookie("cookie[three]", "cookiethree");
      // setcookie("cookie[two]", "cookietwo");
      // setcookie("cookie[one]", "cookieone");
      //setcookie("idconduct", 1);

      //on récupère l'id de l'usager courant à la connexion à la base de données et stocker dans $_SESSION['user_id']
      //mais je n'ai pas fait cela donc je fixe un seul usager pour le test pour le moment
     //setcookie("user_id", "4");//id de l'usager courant que je fixe
      // setcookie("code_postal", "H3G 5B7" );//$_POST['code']

    
    ?>
    
</head>
<body >
    
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="./">Brand</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="./">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#auto">Assurance auto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#habitation">Assurance habitation</a>
            </li>
            <li class="nav-item">
              <!-- <a class="nav-link" href="#apropos">A propos</a> -->
            </li>
          </ul>
          <span class="navbar-text">
           
          </span>
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <!-- <a class="nav-link" href="#espace">Espace client</a> -->
              <!--  dopdown button for options of espace client -->
              <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Espace client
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" data-toggle="modal" data-target="#loginModal" href="#loginModal">Se connecter</a>
                  <div class="dropdown-divider"></div><!--diviseur de dropdown-items -->
                  <a class="dropdown-item" data-toggle="modal" data-target="#connectModal" href="#connectModal">Créer un compte</a>
                </div>
              </div>
            </li>
          </ul>
        </div>
    </nav>
    <div class="content" id="content">
          <h3 class="container">  Assurance automobile en ligne</h3> 

          <?php
          
            
          //echo 'Propriétaire du script courant : ' . get_current_user();
          //echo '<br>'.getmygid();
          //echo '<br>'. php_uname('a');
          //echo '<br>';

          $REMOTE_ADDR=getenv('REMOTE_ADDR');
          $ip = $REMOTE_ADDR;
          $host = gethostbyaddr($ip);
          //echo '<br>'.$host;
          echo getenv('HTTP_CLIENT_IP');
          
          ?>
        
          
          <div class="separateur"></div>
          

          <h5 class="conatainer titre" id=""> Services offerts</h5> 
          
           <!-- assurance automobile -->
          <div class="container " id="automobile" >
            <h5 class="titre">Assurance automobile</h5>
           
          </div><!-- / automobile <br>-->


          <!-- Modal login-->
          <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="loginModalLabel">Connectez-vous à votre compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form method="post" id="login" >
                    <div class="form-group">
                      <label for="email1">Email address</label>
                      <input type="email" class="form-control" id="email1" name="email1" aria-describedby="emailHelp" placeholder="Enter email" autocomplete="" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password1">Password</label>
                      <input type="password" class="form-control" id="password1"  name="password1" placeholder="Password" autocomplete = "current-password"  required>
                    </div>
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="check1"  name="check1" value="1">
                      <label class="form-check-label" for="Check1">Se souvenir de moi</label>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <input type="submit"  name="submit" class="btn btn-primary" onclick="requeteLogin('login')" value="Envoyer" />
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal login -->
         

          
          <!-- Modal signUp-->
          <div class="modal fade" id="connectModal" tabindex="-1" role="dialog" aria-labelledby="connectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="connectModalLabel">Créer un compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form  method="post"  id="signUp" onsubmit="return valide()"> <!--action="./server/controller/gestionAssur.php" -->
                  <span id="msgsu"></span>
                    <div class="form-group">
                      <label for="email2">Email address</label>
                      <input type="email" class="form-control" id="email2" name="email2" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password2">Password</label>
                      <input type="password" class="form-control" id="password2"  name="password2" maxlength="12" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                      <label for="password2b">Repeat password</label>
                      <input type="password" class="form-control" id="password2b"  name="password2b" maxlength="12" placeholder="Confirm Password" required>
                      <input type="hidden"  name="action" value="signUp" hidden>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <input type="submit"  name="submit" class="btn btn-primary" data-dismiss="modal" onclick="requeteEnreg('signUp')" value="Envoyer" />
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal sign-up -->

          <!-- enregistrerUsager nouveau-->
          <div class="enregistrerUsager page container" id="page1">
            <h5 class="titre">Nouvel usager? <br>Parlons de vous</h5>
            <form id="enregistrerUsager" name="enregistrerUsager" method="post" onsubmit="return false"> <!--action="./server/controller/gestionAssur.php" -->
              <div class="form-group">
                <label for="titre">Titre</label>
                <select type="text" class="form-control" id="titre" name="titre" >
                  <option value="1">Monsieur</option>
                  <option value="2">Madame</option>
                  <option value="3">Mademoiselle</option>
                </select>
              
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" name="prenom"  id="prenom" placeholder="Prenom" required>
                <label for="nom">Nom</label>
                <input type="text" class="form-control" name="nom"  id="nom" placeholder="Nom" required>
                <label for="email">Courriel</label>
                <input type="email" class="form-control" name="email"  id="email" placeholder="Entrer votre courriel" required>
                <label for="reclammation">À combien d'années remonte votre  dernière reclammation?</label>
                <input type="number" class="form-control" name="reclammation"  id="reclammation" value="0" min="0" placeholder="Nombre d'années" required>
                <label for="date_naiss">Date de naissance</label>
                <input type="date" class="form-control" name="date_naiss"  id="date_naiss" placeholder="Date de naissance" required>
                <input type="hidden" class="form-control" name="action" value="enregistrerUsager" hidden>
              </div>
              <button type="reset" class="btn btn-danger">Effacer</button>&nbsp;
              <div id="btnTest" class=" btn btn-secondary" onclick="chargerInputs1('enregistrerUsager')" >Rviser/Modifier</div> 
              <input type="submit" name="submit" class="btn btn-primary" data-dismiss="modal" onclick="chargerMemoire('enregistrerUsager')"  value="Envoyer" /><!--onclic="requeteEnreg('enregistrerUsager')"  -->
            </form>
          </div> <!-- / enregistrerUsager-->


          <div id="results"></div>
          						
          <!--enregistrerConducteur -->
        
          <div class="enregistrerConducteur  page  container" id="page2">
            <h5  class="titre">Ajouter un conducteur ?</h5>
            <form  method="post" id="enregistrerConducteur" name="enregistrerConducteur" onsubmit="return valide()"> <!--action="./server/controller/gestionAssur.php" -->
              <div class="form-group">
                <label for="etat_matri">État matrimonial</label>
                <select type="text" class="form-control" id="etat_matri" name="etat_matri" >
                  <option value="1">Marié</option>
                  <option value="2">Veuf</option>
                  <option value="3">Divorcé</option>
                  <option value="4">Célibataire</option>
                  <option value="5">Conjoint de fait</option>
                </select>
                <label for="nom2">Nom</label>
                <input type="text"  class="form-control" name="nom" id="nom2" required>
                <label for="prenom2">Prénom</label>
                <input type="text"  class="form-control" name="prenom" id="prenom2" required>
              </div>
              <div class="form-group">
                <label for="statut_prof">statut professionnel</label>
                <select type="text" class="form-control" id="statut_prof" name="statut_prof" >
                  <option value="1">Employé</option>
                  <option value="2">Retraité</option>
                  <option value="3">Étudiant</option>
                  <option value="4">Travailleur autonome</option>
                  <option value="5">Propriétaire d'entreprise</option>
                  <option value="6">Sans emploi</option>
                </select>
                <label for="exist_police1">Existe-t-il une ancienne police?</label>
                <fieldset>
                <legend></legend>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Non</span>
                    </div>
                    <input type="checkbox" class="form-control check" value="0" name="exist_police"  id="exist_police1">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Oui</span>
                    </div>
                    <input type="checkbox" class="form-control check"  value='1' name="exist_police"  id="exist_police2"  />
                  </div>
                </fieldset>
                <label for="nb_an_conduite">Nombre année de conduite</label>
                <input type="number" class="form-control" name="nb_an_conduite"  id="nb_an_conduite" min=0 max=50 length="2" placeholder=0 required/>
                <input type="hidden" name="user_id" id="user_id" >
              </div>
                <input type="hidden" class="form-control" name="action" value="enregistrerConducteur" hidden>
              <button type="reset" class="btn btn-danger">Effacer</button>&nbsp;
              <div id="btnTest" class=" btn btn-secondary" onclick="chargerInputs2('enregistrerConducteur')" >Reviser/Modifier</div> 
              <input type="submit" name="submit" class="btn btn-primary" data-dismiss="modal" onclick="chargerMemoire('enregistrerConducteur')"  value="Envoyer" /><!--onclic="requeteEnreg('enregistrerConducteur')"  -->
           </form>
           <!--<div class="btn-success" id="" onclick="nouveau('enregistrerConducteur')" style="width:20px">Nouveau</div>   Non géré -->
          </div> <!-- / enregistrerConducteur-->


          <!--enregistrerCoordonnees -->
          <div class="enregistrerCoordonnees  page  container" id="page3">
            <h5  class="titre"> Prenons vos coordonnées</h5><br>
            <form  id="enregistrerCoordonnees" name="enregistrerCoordonnees" method="post" onsubmit="return valide()">
              <div class="form-group"> 
                <label for="code_postal">Entrer votre code postal</label>
                <input type="text" class="form-control" name="code_postal"  id="code_postal" maxlength="7" placeholder=" votre code postal">
                <label for="num_rue">Numéro de rue</label>
                <input type="number" class="form-control" name="num_rue"  id="num_rue" min=1 placeholder="Numéro de rue" required>
                <label for="nom_rue">Nom de rue</label>
                <input type="text" class="form-control" name="nom_rue"  id="nom_rue" placeholder="Nom de rue" required>
                <label for="appart_num">Numéro d'appartement</label>
                <input type="number" class="form-control" name="appart_num"  id="appart_num" min=1 placeholder="Numéro d'appartement" required>
                <label for="num_tel">Numéro de téléphone</label>
                <input type="number" class="form-control" name="num_tel"  id="num_tel" maxlength="12" min='1' placeholder="Numéro de téléphone" required>

                <label for="titre">Type de télélphone</label>
                <select class="form-control" id="idtype_tel" name="idtype_tel" >
                  <option value="1">Fixe</option>
                  <option value="2">Mobile</option>
                  <option value="3">Travail</option>
                </select>
                <input type="hidden" class="form-control" name="action" value="enregistrerCoordonnees" hidden>
              </div>
              <div class="form-group">
              <input type=" hidden"  name="idconduct" id="idconduct1" hidden>
              </div>
              <button type="reset" class="btn btn-danger">Effacer</button>&nbsp;
              <div id="btnTest" class=" btn btn-secondary" onclick="chargerInputs3('enregistrerCoordonnees')" >Reviser/Modifier</div> 
              <input type="submit" name="submit" class="btn btn-primary" data-dismiss="modal" onclick="chargerMemoire('enregistrerCoordonnees')" value="Envoyer" />
            </form>
          </div> <!-- / enregistrerCoordonnées-->


          								

          <!--enregistrerVehicules -->
          <div class="enregistrerVehicules  page  container" id="page4">
            <h5  class="titre">Informations sur le véhicule</h5><br>
            <form id="enregistrerVehicules"  name="enregistrerVehicules"  method="post" onsubmit="return valide()"> <!--action="./server/controller/gestionAssur.php" -->
              <div class="form-group">
                <label for="annee">Année</label>
                <input type="number" class="form-control" name="annee"  id="annee" min='1900' max="2020" placeholder="Annee du véhicule" required>
                <label for="date_acquisition">Date d'acquisition</label>
                <input type="date" class="form-control" name="date_acquisition"  id="date_acquisition" placeholder="Année d'acquisition">
                <label for="km_par_an">Nombre de km parcourru par année</label>
                <input type="number" class="form-control" name="km_par_an"  id="km_par_an" value="100" min=1 placeholder="Nombre de km parcourru par année" >
                <label for="utilisation_commerciale">Utilisation commerciale?</label>
              
                <fieldset>
                <legend></legend>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Non</span>
                    </div>
                    <input type="checkbox" class="form-control check" value="0" name="utilisation_commerciale"  id="utilisation_commerciale1">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Oui</span>
                    </div>
                    <input type="checkbox" class="form-control check"  value="1" name="utilisation_commerciale"  id="utilisation_commerciale2" checked=checked />
                  </div>
                </fieldset>
                
                <label for="date_entree_vigueur">Date d'entrée en vigueur</label>
                <input type="date" class="form-control" name="date_entree_vigueur"  id="date_entree_vigueur" >

                <label for="idmarques">Marque :</label>
                <select class="form-control" id="idmarques" name="idmarques" >
                  <option value="1">Toyota</option>
                  <option value="2">Honda</option>
                  <option value="3">Chevrolet</option>
                  <option value="4">Mercedes</option>
                  <option value="5">Mazda</option>
                </select>
                <label for="idmodeles">Modèle : </label>
                <select class="form-control" id="idmodeles" name="idmodeles" >
                  <option value="1">Modele 1</option>
                  <option value="2">Modele 2</option>
                  <option value="3">Modele 3</option>
                </select>
                <label for="idtype_pos">Type de pocession : </label>
                <select class="form-control" id="idtype_pos" name="idtype_pos" >
                  <option value="1">Acheté et payé totalement</option>
                  <option value="2">Acheté et paiement en financement</option>
                  <option value="3">Loué</option>
                </select>
                <input type="hidden" class="form-control" name="action" value="enregistrerVehicules" hidden>
              </div>
              <div class="form-group">
              <input type=" hidden"  name="idconduct" id="idconduct2" hidden>
              </div>
              <button type="reset" class="btn btn-danger">Effacer</button>&nbsp;
              <div id="btnTest" class=" btn btn-secondary" onclick="chargerInputs4('enregistrerVehicules')" >Reviser/Modifier</div> 
              <input type="submit"  name="submit" class="btn btn-primary"  onclick="chargerMemoire('enregistrerVehicules')" value="Envoyer" /> <!--  onclick="requeteEnreg('enregistrerVehicules')-->
            </form>
          </div> <!-- / enregistrerVehicules-->

          <!-- Fin de soumission -->
          <div class="page  container" id="page5">
              <button type="button" class="btn-danger" onclick="supprimer()">Supprimer</button>
              <button type="button" class="btn-primary" onclick="modifier()" >Modifier tout</button>
              <button type="submit" class="btn-success" onclick="envoyer()" >Envoyer la soumission</button>
         </div>


    </div> <!-- / content-->

      <footer class="footer container" id="">
        
        <div>Bas de page</div>
        <!-- Pagination -->
        <nav aria-label="..." id="nav-pagination">
          <div class="" id="msg" ></div>
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
            </li>
            <li class="page-item active"><a class="page-link" href="#page1">1</a></li>
            <li class="page-item " aria-current="page">
              <a class="page-link" href="#page2">2 <span class="sr-only">(current)</span></a>
            </li>
            <li class="page-item"><a class="page-link" href="#page3">3</a></li>
            <li class="page-item"><a class="page-link" href="#page4">4</a></li>
            <li class="page-item"><a class="page-link" href="#page5">5</a></li>
            <li class="page-item">
              <a class="page-link" href="#">Next</a>
            </li>
          </ul>
        </nav>
        <div class="separateur"></div>
      </footer>
    
      <script src="server/requetes/requeteEnregistrer.js"></script>
      <script src="./src/js/script.js"></script>
</body>
</html>