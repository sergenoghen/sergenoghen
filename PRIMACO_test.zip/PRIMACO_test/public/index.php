<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assurance en ligne</title>
    <script src="./src/js/jquery-3.5.1.min.js"></script>
    <script src="./src/bootstrap-4.5.0/assets/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./src/bootstrap-4.5.0/assets/dist/css/bootstrap.min.css">
    <script src="server/requetes/requeteEnregistrer.js"></script>
    <link rel="stylesheet" href="./src/css/style.css">
    <script src="./src/js/script.js"></script>
    <?php

    ?>
    
</head>
<body onload="">
    
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="./">Brand</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="./">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#auto">Assurance auto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#habitation">Assurance habitation</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#apropos">A propos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact</a>
            </li>
          </ul>
          <span class="navbar-text">
           
          </span>
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <!-- <a class="nav-link" href="#espace">Espace client</a> -->
              <!--  dopdown button for options of espace client -->
              <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Espace client
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" data-toggle="modal" data-target="#loginModal" href="#loginModal">Se connecter</a>
                  <div class="dropdown-divider"></div><!--diviseur de dropdown-items -->
                  <a class="dropdown-item" data-toggle="modal" data-target="#connectModal" href="#connectModal">Créer un compte</a>
                </div>
              </div>
            </li>
          </ul>
        </div>
    </nav>
    <div class="content" id="">
          <h3 class="container">  Assurance en ligne</h3> 

          <?php
          
            
          echo 'Propriétaire du script courant : ' . get_current_user();
          //echo '<br>'.getmygid();
          echo '<br>'. php_uname('a');
          echo '<br>';

          $REMOTE_ADDR=getenv('REMOTE_ADDR');
          $ip = $REMOTE_ADDR;
          $host = gethostbyaddr($ip);
          echo '<br>'.$host;
            echo getenv('HTTP_CLIENT_IP');
          
          ?>
          
          
          <div class="separateur"></div>

          <h5 class="conatainer titre" id=""> Services offerts</h5> 
          
           <!-- assurance automobile -->
          <div class="container " id="automobile" >
            <h5 class="titre">Assurance automobile</h5>
            <div class="" id="">
              
                SERVICES EN LIGNE
                Gérez vos assurances sans avoir besoin de nous appeler. 
                Faites une soumission aujourd'hui pour avoir la meilleure prime d’assurance de différents véhicules, remisez un véhicule et plus encore!
              
            </div>
            <div class=" btn-success"  onclick="location.assign('auto.php')" >Go to</div>
          </div><!-- / automobile <br>-->

          <!-- assurance habitation -->
          <div class="container " id="habitation" >
            <h5 class="titre">Assurance habitation</h5>
            <div class="" id="">
              
              SERVICES EN LIGNE
              Gérez vos assurances sans avoir besoin de nous appeler. 
              Faites une soumission aujourd'hui pour avoir la meilleure prime d’assurance de votre habitation.
            
            </div>
            <div class=" btn-success"  onclick="location.assign('habitation.php')">Go to</div>
          </div><!-- / habitation <br>-->


          <!-- Modal login-->
          <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="loginModalLabel">Connectez-vous à votre compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form method="post" action="./pageclient.php">
                    <div class="form-group">
                      <label for="email1">Email address</label>
                      <input type="email" class="form-control" id="email1" name="email1" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password1">Password</label>
                      <input type="password" class="form-control" id="password1"  name="password1" placeholder="Password" required>
                    </div>
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="check1"  name="check1">
                      <label class="form-check-label" for="Check1">Se souvenir de moi</label>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Envoyer</button>
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal login -->
         

          
          <!-- Modal signUp-->
          <div class="modal fade" id="connectModal" tabindex="-1" role="dialog" aria-labelledby="connectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="connectModalLabel">Créer un compte</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form  method="post"  id="signUp" onsubmit="return false"> <!--action="./server/controller/gestionAssur.php" -->
                  <span id="msgsu"></span>
                    <div class="form-group">
                      <label for="email2">Email address</label>
                      <input type="email" class="form-control" id="email2" name="email2" aria-describedby="emailHelp" placeholder="Enter email" required>
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                      <label for="password2">Password</label>
                      <input type="password" class="form-control" id="password2"  name="password2" maxlength="12" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                      <label for="password2b">Repeat password</label>
                      <input type="password" class="form-control" id="password2b"  name="password2b" maxlength="12" placeholder="Confirm Password" required>
                      <input type="hidden"  name="action" value="signUp" hidden>
                    </div>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary" data-dismiss="modal" onclick="requeteEnreg('signUp')" >Envoyer</button>
                  </form>
                </div>
                <div class="modal-footer">
                </div>
              </div>
            </div>
          </div><!-- /Modal sign-up -->



    </div> <!-- / content-->

      <footer class="footer container" id="">
        
        <div>Bas de page</div>
        <!-- Pagination -->
        <nav aria-label="..." id="nav-pagination">
          <div class="" id="msg" ></div>
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
            </li>
            <li class="page-item"><a class="page-link" href="#page1">1</a></li>
            <li class="page-item active" aria-current="page">
              <a class="page-link" href="#page2">2 <span class="sr-only">(current)</span></a>
            </li>
            <li class="page-item"><a class="page-link" href="#page3">3</a></li>
            <li class="page-item"><a class="page-link" href="#page4">4</a></li>
            <li class="page-item">
              <a class="page-link" href="#">Next</a>
            </li>
          </ul>
        </nav>
        <div class="separateur"></div>
      </footer>
    
</body>
</html>