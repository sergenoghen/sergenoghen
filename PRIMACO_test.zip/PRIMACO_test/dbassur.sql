-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  Dim 26 juil. 2020 à 08:31
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `dbassur`
--

-- --------------------------------------------------------

--
-- Structure de la table `conducteurs`
--

CREATE TABLE `conducteurs` (
  `idconduct` int(11) NOT NULL,
  `nom` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `exist_ancien_police` tinyint(4) DEFAULT NULL,
  `nb_an_conduite` int(11) DEFAULT NULL,
  `idstatut_prof` int(11) NOT NULL,
  `idetat_matri` int(11) NOT NULL,
  `idusers` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Déchargement des données de la table `conducteurs`
--

INSERT INTO `conducteurs` (`idconduct`, `nom`, `prenom`, `exist_ancien_police`, `nb_an_conduite`, `idstatut_prof`, `idetat_matri`, `idusers`) VALUES
(8, 'alabe', 'martine', 0, 14, 1, 1, 1),
(11, 'kawalab', 'majolie', 0, 11, 1, 1, 1),
(15, 'alabe', 'martine', 0, 14, 1, 1, 4),
(18, 'ganoua', 'maroua', 1, 3, 4, 5, 72),
(19, 'ganoua', 'maroua', 1, 3, 4, 5, 73);

-- --------------------------------------------------------

--
-- Structure de la table `connexion`
--

CREATE TABLE `connexion` (
  `pass` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idusers` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Structure de la table `coordonnees`
--

CREATE TABLE `coordonnees` (
  `idcoord` int(11) NOT NULL,
  `code_postal` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num_rue` int(11) DEFAULT NULL,
  `nom_rue` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `appart_num` int(11) DEFAULT NULL,
  `num_tel` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idtype_tel` int(11) NOT NULL,
  `idconduct` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `coordonnees`
--

INSERT INTO `coordonnees` (`idcoord`, `code_postal`, `num_rue`, `nom_rue`, `appart_num`, `num_tel`, `idtype_tel`, `idconduct`) VALUES
(1, 'h1Z3b4', 145, 'MontrÃ©al', 8, '4577854585', 3, 19);

-- --------------------------------------------------------

--
-- Structure de la table `etat_matrimonial`
--

CREATE TABLE `etat_matrimonial` (
  `idetat_matri` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `etat_matrimonial`
--

INSERT INTO `etat_matrimonial` (`idetat_matri`, `nom`) VALUES
(1, 'marié'),
(2, 'veuf'),
(3, 'divorcé'),
(4, 'célibataire'),
(5, 'conjoint de fait');

-- --------------------------------------------------------

--
-- Structure de la table `marques`
--

CREATE TABLE `marques` (
  `idmarques` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `marques`
--

INSERT INTO `marques` (`idmarques`, `nom`) VALUES
(1, 'Toyota'),
(2, 'Honda'),
(3, 'Chevrolet'),
(4, 'Mercedes'),
(5, 'Mazda');

-- --------------------------------------------------------

--
-- Structure de la table `modeles`
--

CREATE TABLE `modeles` (
  `idmodeles` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `modeles`
--

INSERT INTO `modeles` (`idmodeles`, `nom`) VALUES
(1, 'modele 1'),
(2, 'modele 2'),
(3, 'modele 3'),
(4, 'modele 4'),
(5, 'modele 5');

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `idnotif` int(11) NOT NULL,
  `date_debut` date DEFAULT NULL,
  `actif` tinyint(4) DEFAULT NULL,
  `idusers` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `statut_prof`
--

CREATE TABLE `statut_prof` (
  `idstatut_prof` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `statut_prof`
--

INSERT INTO `statut_prof` (`idstatut_prof`, `nom`) VALUES
(1, 'employé'),
(2, 'retraité'),
(3, 'étudiant'),
(4, 'travailleur autonoome'),
(5, 'à la maison'),
(6, 'propriétaire d\'entreprise');

-- --------------------------------------------------------

--
-- Structure de la table `type_possession`
--

CREATE TABLE `type_possession` (
  `idtype_pos` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `type_possession`
--

INSERT INTO `type_possession` (`idtype_pos`, `nom`) VALUES
(1, 'acheté et payé totalement'),
(2, 'acheté et paiement en financement'),
(3, 'loué');

-- --------------------------------------------------------

--
-- Structure de la table `type_tel`
--

CREATE TABLE `type_tel` (
  `idtype_tel` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `type_tel`
--

INSERT INTO `type_tel` (`idtype_tel`, `nom`) VALUES
(1, 'fixe'),
(2, 'mobile'),
(3, 'travail');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `idusers` int(11) NOT NULL,
  `titre` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prenom` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nom` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_naiss` date DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `nbreAnneeReclamAnterieure` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`idusers`, `titre`, `prenom`, `nom`, `date_naiss`, `email`, `nbreAnneeReclamAnterieure`) VALUES
(1, 'Madame', 'srge', 'tagne', '1988-11-11', '', 0),
(3, 'Monsieur', 'serge', 'tagne', '1988-11-11', 'serge@yahoo.fr', 7),
(4, 'Monsieur', 'serge', 'tagen', '2018-12-05', 'serge@gmail.com', 0),
(7, 'Monsieur', 'fyguhij', 'yfugih', '1999-11-11', 'yoyo@yahoo.fr', 0),
(8, 'Monsieur', 'miche', 'perso', '2019-10-08', 'miche@gmail.com', 0),
(25, 'Mademoiselle', 'zeno', 'ben', '2019-03-06', 'ben@yahoo.fr', 1),
(26, 'Monsieur', 'lendi', 'pk18', '2019-08-16', 'allo@gmail.com', 2),
(27, '2', 'pagel', 'camoni', '2019-12-18', 'aserr@yahoo.fr', 5),
(73, '1', 'zeno 2', 'fabrice 2', '2019-12-11', 'zeno2@yahoo.fr', 17);

-- --------------------------------------------------------

--
-- Structure de la table `vehicules`
--

CREATE TABLE `vehicules` (
  `idv` int(11) NOT NULL,
  `annee` int(5) DEFAULT NULL,
  `date_acquisition` date DEFAULT NULL,
  `km_par_an` int(11) DEFAULT NULL,
  `utilisation_commerciale` tinyint(4) DEFAULT NULL,
  `date_entree_vigueur` date DEFAULT NULL,
  `idmarques` int(11) NOT NULL,
  `idmodeles` int(11) NOT NULL,
  `idconduct` int(11) NOT NULL,
  `idtype_pos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `vehicules`
--

INSERT INTO `vehicules` (`idv`, `annee`, `date_acquisition`, `km_par_an`, `utilisation_commerciale`, `date_entree_vigueur`, `idmarques`, `idmodeles`, `idconduct`, `idtype_pos`) VALUES
(1, 2000, '2020-01-08', 100, 1, '2019-12-12', 3, 2, 19, 3);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `conducteurs`
--
ALTER TABLE `conducteurs`
  ADD PRIMARY KEY (`idconduct`,`idstatut_prof`,`idetat_matri`,`idusers`),
  ADD UNIQUE KEY `nom` (`nom`,`prenom`,`idusers`),
  ADD KEY `fk_condcuteurs_users` (`idusers`) USING BTREE,
  ADD KEY `fk_condcuteurs_statut_prof` (`idstatut_prof`),
  ADD KEY `fk_condcuteurs_etat_matrimonial` (`idetat_matri`);

--
-- Index pour la table `connexion`
--
ALTER TABLE `connexion`
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD KEY `login_users_fk` (`idusers`);

--
-- Index pour la table `coordonnees`
--
ALTER TABLE `coordonnees`
  ADD PRIMARY KEY (`idcoord`,`idtype_tel`),
  ADD KEY `fk_coordonnees_type_tel1` (`idtype_tel`),
  ADD KEY `coordonnees_ibfk_conducteurs` (`idconduct`);

--
-- Index pour la table `etat_matrimonial`
--
ALTER TABLE `etat_matrimonial`
  ADD PRIMARY KEY (`idetat_matri`);

--
-- Index pour la table `marques`
--
ALTER TABLE `marques`
  ADD PRIMARY KEY (`idmarques`);

--
-- Index pour la table `modeles`
--
ALTER TABLE `modeles`
  ADD PRIMARY KEY (`idmodeles`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`idusers`);

--
-- Index pour la table `statut_prof`
--
ALTER TABLE `statut_prof`
  ADD PRIMARY KEY (`idstatut_prof`);

--
-- Index pour la table `type_possession`
--
ALTER TABLE `type_possession`
  ADD PRIMARY KEY (`idtype_pos`);

--
-- Index pour la table `type_tel`
--
ALTER TABLE `type_tel`
  ADD PRIMARY KEY (`idtype_tel`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idusers`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `prenom` (`prenom`,`nom`,`date_naiss`);

--
-- Index pour la table `vehicules`
--
ALTER TABLE `vehicules`
  ADD PRIMARY KEY (`idv`,`idmarques`,`idmodeles`,`idconduct`,`idtype_pos`),
  ADD KEY `fk_vehicules_marques` (`idmarques`),
  ADD KEY `fk_vehicules_condcuteurs1` (`idconduct`),
  ADD KEY `fk_vehicules_type_possession1` (`idtype_pos`),
  ADD KEY `fk_vehicules_modeles1` (`idmodeles`) USING BTREE;

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `conducteurs`
--
ALTER TABLE `conducteurs`
  MODIFY `idconduct` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `coordonnees`
--
ALTER TABLE `coordonnees`
  MODIFY `idcoord` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `etat_matrimonial`
--
ALTER TABLE `etat_matrimonial`
  MODIFY `idetat_matri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `marques`
--
ALTER TABLE `marques`
  MODIFY `idmarques` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `modeles`
--
ALTER TABLE `modeles`
  MODIFY `idmodeles` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `statut_prof`
--
ALTER TABLE `statut_prof`
  MODIFY `idstatut_prof` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `type_possession`
--
ALTER TABLE `type_possession`
  MODIFY `idtype_pos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `type_tel`
--
ALTER TABLE `type_tel`
  MODIFY `idtype_tel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `idusers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT pour la table `vehicules`
--
ALTER TABLE `vehicules`
  MODIFY `idv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `conducteurs`
--
ALTER TABLE `conducteurs`
  ADD CONSTRAINT `fk_condcuteurs_etat_matrimonial` FOREIGN KEY (`idetat_matri`) REFERENCES `etat_matrimonial` (`idetat_matri`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_condcuteurs_statut_prof` FOREIGN KEY (`idstatut_prof`) REFERENCES `statut_prof` (`idstatut_prof`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `connexion`
--
ALTER TABLE `connexion`
  ADD CONSTRAINT `login_users_fk` FOREIGN KEY (`idusers`) REFERENCES `users` (`idusers`) ON DELETE CASCADE;

--
-- Contraintes pour la table `coordonnees`
--
ALTER TABLE `coordonnees`
  ADD CONSTRAINT `coordonnees_ibfk_conducteurs` FOREIGN KEY (`idconduct`) REFERENCES `conducteurs` (`idconduct`);

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_users1` FOREIGN KEY (`idusers`) REFERENCES `users` (`idusers`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `vehicules`
--
ALTER TABLE `vehicules`
  ADD CONSTRAINT `fk_vehicules_condcuteurs1` FOREIGN KEY (`idconduct`) REFERENCES `conducteurs` (`idconduct`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vehicules_marques` FOREIGN KEY (`idmarques`) REFERENCES `marques` (`idmarques`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vehicules_modeles1` FOREIGN KEY (`idmodeles`) REFERENCES `modeles` (`idmodeles`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vehicules_type_possession1` FOREIGN KEY (`idtype_pos`) REFERENCES `type_possession` (`idtype_pos`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
