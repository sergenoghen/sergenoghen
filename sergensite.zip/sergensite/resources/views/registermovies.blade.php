

      <form method='post' action="./enregistrerMembre.php"  class="form" id="formSignUp" onsubmit="return valider( 'formSignUp' )"> 
        <div class="modal-body" name="modal_body">
            <label for="nom"><b>Nom</b></label>
            <input type="text"  name="nom" placeholder="Entrer le nom" required><br>

            <label for="prenom"><b>Prénom</b></label>
            <input type="text" name="prenom" placeholder="Entrer votre prénom"  required><br>

            <star class="star">*</star>
            <label for="email"><b>Courriel</b></label>
            <input type="email" placeholder="Entrer Email" name="email" required><br>

            <star class="star">*</star>
            <label for="psw"><b>Mot de passe</b></label>
            <input type="password" placeholder="Entrer mot de passe" name="psw" minlength="6" maxlength="12" required>
            <br>
            <label for="psw_repeat"><b>Confirmer mot de passe</b></label>
            <input type="password" placeholder="Retaper mot de passe" name="psw_repeat" required><br>
            <span name="msg" id="msgUpload"></span>
        </div>
        <div class="modal-footer" name="modal_footer"> 
          <!--<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="reset" class="btn btn-primary"> Effacer</button> -->
          <span id="msg"></span>
          <button type="submit" name='submit' class="btn btn-primary" >Envoyer</button>
        </div>
      </form>

<!-- <p>Ici les films</p>
Email : {!!Form::label('email :')!!}
{!! Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Votre email']) !!}
<br> -->

<?php

// echo Form::label('email :');
// echo Form::email('email_name', 'valeur dans le input de email', ['class' => 'form-control', 'placeholder' => 'Votre email']);
// echo '<br>';
// echo Form::text('text_name', 'valeur dans le input text', ['class' => 'form-control', 'placeholder' => 'le texte']);
// //ipnut de type email
// //name : email_name
// //echo Form::submit('submit','envoyer',['class'=>'btn-primary']);

