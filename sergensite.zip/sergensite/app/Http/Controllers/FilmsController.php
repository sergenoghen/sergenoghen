<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FilmsController extends Controller
{
    //
    //méthode getForm pour recueillir
    public function getForm()
	{
		return view('registermovies');
    } 
}
