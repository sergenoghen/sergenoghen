
function videoStop(id){
    obj = document.getElementById(id);
    obj.pause();
}

function gererVideo(elem){
    elem.classList.add("playing");
   
    if(elem.className == "stop"){
        elem.classList.add("playing");
    }
    console.log(elem.className);
}

 if(tab = $(".video") ){
        tab.each(function(index, val){
            val.classList.remove("stop");
            console.log( eval(index + 1) + "  "  + val.className );
            // elem.classList.add("playing");
        });
    }

//console.log( "Taille = " +$(".modalVideo").toArray().length);

// try {
//     if (!document.pictureInPictureElement) {
//         console.log(videoElement.requestPictureInPicture() );
//         videoElement.requestPictureInPicture();
//     } else {
//         document.exitPictureInPicture();
//     }
// } catch(reason) {
//     console.error(reason);
// }


// document.body.addEventListener("click",function(event){
//     console.log("click fait "+event.target.nodeName);
//     if(event.target.nodeName == "video".toUpperCase()){
//         console.log("!= video");
//         for(i=0 ; i < (tabVideo =$(".video")).toArray().length ; i++){
//             tabVideo[i].classList.add("playing");
//             console.log(tabVideo[i].className);
//             //console.log( "i = " + i + " " + tabVideo[i].pause() );
            
//             tabVideo[i].blur(function(){
//                 console.log("blur appelé " + tabVideo[i]);
//             }); 

//              videoElement = tabVideo[i];           
//             try {
//                 if (!document.pictureInPictureElement) {
//                     console.log(videoElement.requestPictureInPicture() );
//                     videoElement.requestPictureInPicture();
//                 } else {
//                     document.exitPictureInPicture();
//                 }
//             } catch(reason) {
//                 console.error(reason);
//             }
            

//         }
//     }


// });
