//afficher la lister de tous les films à l'accueil par catégorie
function afficher(){
    $("#affichage").hide();
    $("#affichage2").show('slow');
}



function valider(id){
    var formDat = new FormData(document.getElementById(id) );

    var chars = ['[',' )','(','{','}','<','>','#',"="];
    compte =0;
    var msg="" ,err = "";;
    let regexText = /\w/;
    premier = null;
    
    error = document.getElementById("msg");  
    error.innerHTML="";  
    error.style.color="red";
    let setError = new Set();
    formDat.forEach(function(value, name){
            
            if(typeof(value) != "object" && value.trim() == "" ){//si un text vide
                setError.add("<br>Veuillez renseigner tous les champs svp!") ;
                //document.getElementsByName(name)[compte].style.background="red";
                
            }else if(typeof(value) == "object"){// si non si input est image ou video
                //console.log(value.type);//.name.lastIndexOf(".jpg")
                if(value.type != "video/mp4" && value.type != "image/jpeg"){
                   setError.add("<br>Fichier média vidéo / image invalides!");
                    
                }
                if(value.name == ""){
                   setError.add("<br>Fichier média vidéo / image vide!");
                 
                }else if(premier == value.type){
                    setError.add("<br>Vous avez choisit deux fichiers media de même type");
                  
               }
               
                premier = value.type;
              //console.log("Nom = "+value.name + "\nDate =  " + value.lastModifiedDate + "\nType =  " + value.type + "\nTaille =  " + value.size);
                                        
            }else  if(!regexText.test(value)){//si non text non vide contenant des caractères exclus
                         
                setError.add("<br>Seuls les caractères alpha-numériques et tiret-soulignés autorisés.");
               
            }else{
                
                if(name.trim() == "prix" && !parseFloat(value)) setError.add("Veuillez entrer un prix valide svp!");
               
                //les caratères interdits dans les champs pour éviter l'injection des requetes dans les inputs
                chars.forEach(element => {
                    if(value.indexOf(element) > -1 ){
                        
                        setError.add("<br>Les caractères suivants " + chars.toString() + " sont interdits!");
                        
                    }
                                   
                });

            }
          
        compte++;
    
    });
        let taille = 0;
        for(a of setError){
            taille++;
            error.innerHTML = (a);
        }

        //console.log("Compte = " + compte + "  Taille= " +taille);
        if(taille == 0){
            return true;
        } else{
            return false;
        }
}
