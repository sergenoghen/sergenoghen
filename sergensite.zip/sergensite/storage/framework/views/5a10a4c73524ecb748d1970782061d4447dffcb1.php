
<p>page numero <?php echo e($numero); ?> </p><?php /**PATH C:\laragon\www\unsite\sergensite\resources\views/page.blade.php ENDPATH**/ ?>