<?php 
  session_start(); 
  
?>
<!DOCTYPE html>

<html lang="fr">
	<head>
		<title>Video films steaming</title> 
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="content=initial-scale=1, width=device-width">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1, minimum-scale=0.5">
		<meta name="description" content="">
	   
		<script src="./js/jquery-3.5.1.min.js"></script>      
		
		<script src="./js/script.js"></script>
		<script src="./requetes/requeteLire.js"></script>
		<script src="./requetes/requeteEnregistrer.js"></script>
		<script src="./bootstrap-4.5.0/assets/dist/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="./bootstrap-4.5.0/assets/dist/css/bootstrap.min.css"><!--  -->
		<link rel="stylesheet" href="./css/card.css">
	   
		<link href="./css/signup-singin.css" rel="stylesheet">

  </head>
  <body onload="requeteLire()"> 
    
    <header>
    
		<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
		  
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
			  <span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarsExample03">
			  <ul class="navbar-nav mr-auto">
				<li class="nav-item active">
				  <a class="nav-link" href="./">Home <span class="sr-only">(current)</span></a>
				</li>
				
				<li class="nav-item">
					<form method="post" id="listeFilms" onsubmit="return false">
						<a class="nav-link"   href="#Nosfilms" onclick="listeFilms()">Nos films</a>
						<input type="hidden" name="action" value="listeFilms" hidden>
					</form>
				</li>
				
				<li class="nav-item dropdown">
				  <a class="nav-link dropdown-toggle"   id="categoried" href="#categorie" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Catégorie</a>
				  <form  method="post" id="formCateg"> 
					<select  class="dropdown-menu" id="categorie" name="categorie" class="dropdown-menu" aria-labelledby="categoried" onchange="listeFilmsCateg(this.options[selectedIndex].value)"> 
					  <option value=""class="dropdown-item">Choisir </option> 
					  <option value="action" class="dropdown-item">Action </option> 
					  <option value="comedie"class="dropdown-item">Comedie </option> 
					  <option value="drame" class="dropdown-item">Drame </option> 
					  <option value="fiction" class="dropdown-item">Fiction </option> 
					  <option value="horreur" class="dropdown-item">Horreur </option> 
					  <option value="aventure" class="dropdown-item">Aventure </option> 
					</select>
					<!-- <input type="button" value="Envoyer" onclick="listeFilmsCateg()"/> -->
				  </form>
				</li>
				<li class="nav-item">
				  <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"></a>
				</li>
			  </ul>
			  <ul class="nav navbar-nav navbar-right">

				<li class="nav-item" >
					<a href="#" class="nav-link" data-toggle="modal" data-target="#enregistrer">
					  <span class="glyphicon glyphicon-user" ></span>
					  Ajouter
					</a>
					</li>
				
			  </ul>
			</div>
			
		</nav>
	</header>

<main role="main">

<h3 id="titre"> &nbsp;Gestion des films </h3>


<!-- Debut Affichage global-->

	<div class="album py-5 bg-light">
		<div class="container"><!-- Conteneur des cards -->
			<div class="row" id="affichage"  > 
				<!-- Affichage des films ici -->
        
        <!-- Loading-->
		<!--		
        <div class="container bg-light" id="contloading2" style="width:320px; font-size:20px;color:green;text-align:center"> <br>
       
          <div class="spinner-grow text-primary container" id="loading2" role="status">
            <span class="sr-only">Loading...</span> 
          </div>
          <div> Chargement en cours ...</div>
        </div>/ Loading-->

			</div> <!-- / .row -->
			  
		</div>
		<div class="container" id="affichage2">
    
		</div>
    </div>
  </div>


<!-- </div>Fin Affichage global-->

  <!--<div class="album py-5 bg-light">  -->
  

 
 <!--Modals begin here -->

 <!-- Modals-->
    <!-- modal enregistrer films -->
    <div class="modal fade" tabindex="-1" role="dialog" id="enregistrer" aria-labelledby="enregistrerModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Enregistrer</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form Ajouter --> 
            <!-- enctype="multipart/form-data" Utiliser pour upload de fichier-->
            <form  method="post" id="enregistrerFilms" enctype="multipart/form-data" onsubmit="return false">  <!-- <div class="form-group">
                <label for="exampleInputEmail1">Numero du films</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Le numéro du film">
              </div> 
              <div class="form-group">-->
                <label for="titre"> Le titre</label>
                <input type="text" class="form-control" id="titre" name="titre" placeholder=" Le titre" required />
                <label for="realisateur"> Le réalisateur</label>
                <input type="text" class="form-control" id="realisateur" name="realisateur" placeholder=" Entrer Le réalisateur" required />
                <label for="categorie"> La catégorie</label>
                <select  class="form-control" id="categorie" name="categorie" > 
                  <option value="action">Action </option> 
                  <option value="comedie">Comedie </option> 
                  <option value="drame">Drame </option> 
                  <option value="fiction">Fiction </option> 
                  <option value="horreur">Horreur </option> 
                  <option value="aventure">Aventure </option> 
                </select>
                <label for="duree">  La durée</label>
                <input type="number" class="form-control" id="duree" name="duree" placeholder="  La durée" min="0" required />
                <label for="prix"> Le prix</label>
                <input type="text" class="form-control" id="prix" name="prix" placeholder=" Le prix" min='0' required />
                 <label for="preview"> Le preview du film</label>
                <input type="file" name="pochette[]"  class="form-control" id="preview"   multiple /> 
                <label for="pochette"> La pochette</label>
                <input type="file" name="pochette[]"  class="form-control" id="pochette" multiple />
                
            <!--  </div>
                -->
                <!-- <input type="datetime-local" name="" id=""> --> 
                <div id="msg"></div>
                <div>
                  <input type="hidden" name="action" value="enregistrerFilms" hidden />
                  <!--<button type="reset" name="reset" class="btn btn-danger">Effacer</button>  -->
                  <button type="submit" name="submit" class="btn btn-primary" onclick="requeteEnreg('enregistrerFilms', this)">Ajouter</button>
                </div>
            </form>
           
          </div>
          <div class="modal-footer">
            <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" onclick="ajouter()">Ajouter</button> -->
          </div>
        </div>
      </div>
    </div><!--/enregistrer-->

  
</div>

</main>

<footer class="text-muted">
<div class=" bg-dark" >
    &COPY; 2020 May
  </div>
  
</footer>

<script src=".//js/video.js"></script>
<script src="./requetes/requeteLire.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\unsite\sergensite\resources\views/gererFilms.blade.php ENDPATH**/ ?>